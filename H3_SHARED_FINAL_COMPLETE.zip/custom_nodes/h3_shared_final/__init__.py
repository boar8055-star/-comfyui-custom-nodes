# ComfyUI node: output only the final VHS audio-muxed MP4 into one folder.
# No watcher/cron/background script needed. Uses hard links (no duplicate video data)
# when destination is on the same filesystem.
from __future__ import annotations

import errno
import os
import re
import shutil
import sys
import uuid
from datetime import datetime
from pathlib import Path

import folder_paths


class H3SharedFinalSave:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "filenames": ("VHS_FILENAMES",),
                "shared_folder": ("STRING", {"default": "AUTO", "multiline": False}),
                "gpu_tag": (["auto", "gpu1", "gpu2", "gpu3", "gpu4", "gpu5", "gpu6", "gpu7", "gpu8"], {"default": "auto"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("shared_video_path",)
    FUNCTION = "save"
    CATEGORY = "H3 / Final Output"
    OUTPUT_NODE = True

    @staticmethod
    def _gpu_from_output_dir(output_dir: Path) -> str:
        # Each worker runs with --output-directory .../output/gpu1, gpu2, ...
        match = re.fullmatch(r"gpu(\d+)", output_dir.name, re.IGNORECASE)
        if match:
            return f"gpu{int(match.group(1))}"

        # Explicit environment variable can be configured for deployments
        # that use custom output folder names.
        tag = os.environ.get("H3_GPU_TAG", "").strip().lower()
        if re.fullmatch(r"gpu\d+", tag):
            return tag

        # If the worker uses a CUDA device index, GPU 0 is labelled gpu1.
        args = sys.argv
        for i, arg in enumerate(args):
            if arg == "--cuda-device" and i + 1 < len(args):
                if args[i + 1].isdigit():
                    return f"gpu{int(args[i + 1]) + 1}"
            if arg.startswith("--cuda-device="):
                val = arg.split("=", 1)[1]
                if val.isdigit():
                    return f"gpu{int(val) + 1}"

        visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").split(",")[0].strip()
        if visible.isdigit():
            return f"gpu{int(visible) + 1}"
        return "gpu_unknown"

    @staticmethod
    def _shared_directory(root: Path, shared_folder: str) -> Path:
        if shared_folder.strip().upper() in ("", "AUTO"):
            # /workspace/ComfyUI/output/gpu3 -> /workspace/ComfyUI/output/FINAL_AUDIO_ALL_GPU
            # /workspace/ComfyUI/output      -> /workspace/ComfyUI/output/FINAL_AUDIO_ALL_GPU
            if re.fullmatch(r"gpu\d+", root.name, re.IGNORECASE):
                return root.parent / "FINAL_AUDIO_ALL_GPU"
            return root / "FINAL_AUDIO_ALL_GPU"
        p = Path(os.path.expanduser(shared_folder.strip()))
        if not p.is_absolute():
            raise ValueError("shared_folder must be AUTO or an absolute filesystem path")
        return p

    def save(self, filenames, shared_folder="AUTO", gpu_tag="auto"):
        if not isinstance(filenames, (tuple, list)) or len(filenames) < 2:
            raise ValueError(f"Unexpected VHS_FILENAMES structure: {type(filenames)}")
        save_output, paths = filenames[0], filenames[1]
        if not save_output:
            raise ValueError("VHS_VideoCombine save_output is disabled; enable it")
        if isinstance(paths, str):
            paths = [paths]
        if not isinstance(paths, (list, tuple)):
            raise ValueError("VHS_FILENAMES contains no path list")

        # Only choose MP4 files that VHS generated after muxing the audio.
        # This intentionally rejects the preceding silent MP4 and PNG metadata.
        candidates = [Path(p) for p in paths if isinstance(p, (str, os.PathLike))]
        audio_mp4 = [p for p in candidates
                     if p.suffix.lower() == ".mp4" and p.stem.lower().endswith("-audio") and p.is_file()]
        if not audio_mp4:
            raise FileNotFoundError(
                "No final *-audio.mp4 found in VHS_VideoCombine filenames. "
                "Connect AUDIO to VHS_VideoCombine and verify it succeeded. "
                f"Files: {paths!r}"
            )
        source = audio_mp4[-1]
        root = Path(folder_paths.get_output_directory()).resolve()
        dest_dir = self._shared_directory(root, shared_folder)
        dest_dir.mkdir(parents=True, exist_ok=True)
        tag = self._gpu_from_output_dir(root) if gpu_tag == "auto" else gpu_tag

        # UUID makes even simultaneous jobs on different GPUs collision-proof.
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        for _ in range(10):
            dest = dest_dir / f"H3_FINAL_{stamp}_{uuid.uuid4().hex[:8]}_{tag}.mp4"
            try:
                # Hardlink is a second directory entry, not a second copy of the video.
                # Keep the original path so the normal VHS preview keeps working.
                os.link(source, dest)
                mode = "hardlink (no extra disk space)"
                break
            except FileExistsError:
                continue
            except OSError as e:
                # Cross-device/network mounts cannot hardlink. Copy atomically instead.
                if e.errno not in (errno.EXDEV, errno.EPERM, errno.EOPNOTSUPP, errno.ENOTSUP, errno.EACCES):
                    raise
                temp = dest.with_suffix(".part")
                try:
                    with open(source, "rb") as fin, open(temp, "xb") as fout:
                        shutil.copyfileobj(fin, fout, length=8 * 1024 * 1024)
                    shutil.copystat(source, temp)
                    os.replace(temp, dest)
                    mode = "copy (shared filesystem does not support hardlinks)"
                    break
                finally:
                    temp.unlink(missing_ok=True)
        else:
            raise FileExistsError("Could not generate unique name for shared output")

        print(f"[H3SharedFinalSave] {source} -> {dest} [{mode}]")
        return {"ui": {"text": [str(dest)]}, "result": (str(dest),)}


NODE_CLASS_MAPPINGS = {"H3SharedFinalSave": H3SharedFinalSave}
NODE_DISPLAY_NAME_MAPPINGS = {"H3SharedFinalSave": "H3 Save FINAL AUDIO to Shared GPU Folder"}
