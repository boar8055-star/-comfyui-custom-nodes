H3 FINAL AUDIO: auto-save from all GPUs into one folder (inside the workflow)

1. Install the new ComfyUI node once in the ComfyUI installation:
   unzip -o h3_shared_final_node.zip -d /workspace/ComfyUI/custom_nodes/
   (or copy h3_shared_final/__init__.py to /workspace/ComfyUI/custom_nodes/h3_shared_final/__init__.py)

2. Restart your ComfyUI workers: comfyui-gpu1..comfyui-gpu4.
3. Open H3_Cycle_AUTO_SHARED_FINAL.json in every worker.
4. Run generation as before. The VHS_VideoCombine node will encode the final 30fps MP4 + audio,
   then H3SharedFinalSave will immediately place that exact finished MP4 in the shared folder.

With worker outputs /workspace/ComfyUI/output/gpu1..gpu4 the shared folder is:
   /workspace/ComfyUI/output/FINAL_AUDIO_ALL_GPU/

Naming:
   H3_FINAL_20261115_021530_123456_ab12cd34_gpu1.mp4
   H3_FINAL_20261115_021530_123789_12ac34de_gpu3.mp4

No watcher / polling scripts required. On the same filesystem it creates a hardlink
(instant, no extra data space) and keeps the original file accessible for ComfyUI preview.
If the shared path is on a different volume, it makes one copy during workflow execution.

If your workers' output paths do not end in gpu1/gpu2/gpu3/gpu4, set the gpu_tag widget
manually (or set H3_GPU_TAG in each worker's environment). If the output directories
are on separate VPSes, set shared_folder to an absolute mounted shared directory.

Only a completed *-audio.mp4 is selected. No silent MP4, intermediate stages, or PNG files
are written into the shared folder.
