"""H3 Batch — single-pass execution of an UNMODIFIED 101-node original API graph.

Only source video/body folders, face image filenames and unique output prefix
are substituted for each GPU task. Each GPU runs the complete graph, including
character swap, face SAM3 / H3 and RIFE + VHS export, one prompt per video.
"""
import copy
import json
import os
import queue
import re
import shutil
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

import requests
from flask import Flask, Response, jsonify, render_template, request
from onepass import make_graph, original_graph

app = Flask(__name__)
HOME = Path(os.environ.get('H3_BATCH_HOME', '/workspace/h3_batch')).resolve()
HOME.mkdir(parents=True, exist_ok=True)
ROOTS = [Path(x.strip()).resolve() for x in os.environ.get('H3_ALLOWED_ROOTS', '/workspace').split(',') if x.strip()]
COMFY = [f'http://127.0.0.1:{p.strip()}' for p in os.environ.get('H3_COMFY_PORTS', '18188,18189,18190,18191').split(',') if p.strip()]
COMFY_INPUT = Path(os.environ.get('H3_COMFY_INPUT', '/workspace/ComfyUI/input')).resolve()
COMFY_OUTPUT = Path(os.environ.get('H3_COMFY_OUTPUT', '/workspace/ComfyUI/output')).resolve()
# H3 API defaults to no authentication. Use H3_PANEL_PASSWORD only if opted in.
PASSWORD = os.environ.get('H3_PANEL_PASSWORD', '')
VIDEO_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff'}
LOCK = threading.RLock()
ACTIVE = None
ABORT = threading.Event()


def protected(path):
    p = Path(path).expanduser().resolve()
    if not any(p == root or root in p.parents for root in ROOTS):
        raise ValueError('Outside allowed folder: ' + str(p))
    return p


def natural_key(path):
    return [int(s) if s.isdigit() else s.lower() for s in re.split(r'(\d+)', Path(path).name)]


def files_in(folder, exts):
    p = protected(folder)
    if not p.is_dir():
        raise ValueError('Folder not found: ' + str(p))
    return sorted((x for x in p.iterdir() if x.is_file() and x.suffix.lower() in exts), key=natural_key)


def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def persist():
    # Serialize snapshot writes: with 4–8 worker threads a shared *.tmp name
    # previously caused concurrent os.replace() races and lost state updates.
    with LOCK:
        if ACTIVE is None:
            return
        data = copy.deepcopy(ACTIVE)
        target = HOME / 'runs' / data['id'] / 'state.json'
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
            os.replace(tmp, target)
        finally:
            tmp.unlink(missing_ok=True)


def snap():
    with LOCK:
        if ACTIVE is not None:
            return copy.deepcopy(ACTIVE)
    runs = list((HOME / 'runs').glob('*/state.json'))
    if not runs:
        return None
    try:
        d = json.loads(max(runs, key=lambda x: x.stat().st_mtime).read_text())
        if d.get('mode') == 'onepass':
            if d.get('status') in ('starting', 'running'):
                d['status'] = 'interrupted'
            return d
    except (OSError, ValueError):
        pass
    return None


def update_task(run_id, idx, status, gpu=None, error='', **fields):
    with LOCK:
        if ACTIVE is None or ACTIVE['id'] != run_id:
            return
        s = ACTIVE['tasks'][idx]
        s.update(status=status, gpu=gpu, error=str(error)[-2200:], updated=now(), **fields)
    persist()


def update_run(run_id, **kwargs):
    with LOCK:
        if ACTIVE is not None and ACTIVE['id'] == run_id:
            ACTIVE.update(kwargs)
    persist()


def call(session, method, endpoint, timeout=15, **kwargs):
    resp = session.request(method, endpoint, timeout=timeout, **kwargs)
    if not resp.ok:
        raise RuntimeError(f'{endpoint}: HTTP {resp.status_code}: {resp.text[:2500]}')
    return resp.json()


def check_worker(url):
    try:
        with requests.Session() as s:
            info = call(s, 'GET', url + '/system_stats', timeout=3)
        return {'url': url, 'online': True, 'devices': info.get('devices', [])}
    except Exception:
        return {'url': url, 'online': False, 'devices': []}


def preview_compat_needed(session, url):
    # On standard ComfyUI PreviewImage is a sink with no return types.
    try:
        d = call(session, 'GET', url + '/object_info/PreviewImage', timeout=10)
        return not bool(d['PreviewImage'].get('output'))
    except Exception as exc:
        raise RuntimeError(f'Cannot check PreviewImage node on {url}: {exc}') from exc


def wait_idle(session, url, stop):
    limit = time.monotonic() + 1800
    while time.monotonic() < limit:
        if stop.is_set():
            raise RuntimeError('Stop requested')
        q = call(session, 'GET', url + '/queue', timeout=10)
        if not q.get('queue_running') and not q.get('queue_pending'):
            return
        time.sleep(2)
    raise TimeoutError('GPU never became idle: ' + url)


def locate_video(result, gpu, output_prefix=None):
    """Resolve VHS VideoCombine's declared output, not a guessed filename."""
    root = COMFY_OUTPUT / f'gpu{gpu}'
    outputs = result.get('outputs', {})
    record = outputs.get('1277', {})
    for key in ('gifs', 'videos', 'files', 'images'):
        for item in record.get(key, []):
            if not isinstance(item, dict):
                continue
            if not item.get('filename', '').lower().endswith('.mp4'):
                continue
            sub = item.get('subfolder', '')
            p = (root / sub / item['filename']).resolve()
            if root.resolve() in p.parents and p.is_file():
                return p
    if output_prefix:
        # Some VHS versions don't return file metadata in /history.
        # Use the unique per-task prefix, never the last output of another video.
        sub = root / output_prefix
        found = [p for p in sub.parent.glob(sub.name + '*.mp4') if p.is_file()]
        if len(found) == 1:
            return found[0]
    return None


class LostPromptAfterRestart(RuntimeError):
    """The ComfyUI process came back but no longer knows this prompt."""


def execute_one(session, url, item, gpu, stop):
    output = Path(item['final'])
    if output.is_file() and output.stat().st_size > 1000:
        return
    wait_idle(session, url, stop)
    preview_is_sink = preview_compat_needed(session, url)
    compat = bool(item.get('preview_compat', False))
    if preview_is_sink and not compat:
        raise RuntimeError(
            'Оригинальный API JSON подключает H3 node 1154 к PreviewImage 1247, '
            'но стандартный PreviewImage не имеет IMAGE-выхода. '
            'Строгий режим сохраняет граф неизменным. '
            'Для работы можно включить явную галочку совместимости: '
            'тогда только 1154.ref_image_0 направляется напрямую от ImageStitch 1246.'
        )
    graph = make_graph(item['body_dir'], item['video_dir'], item['face_front_rel'],
                       item['face_side_rel'], item['output_prefix'], preview_compat=(preview_is_sink and compat))
    result = call(session, 'POST', url + '/prompt', timeout=60,
                  json={'prompt': graph, 'client_id': 'h3-onepass-' + uuid.uuid4().hex})
    prompt_id = result.get('prompt_id')
    if not prompt_id:
        raise RuntimeError('ComfyUI refused prompt: ' + json.dumps(result, ensure_ascii=False)[:1500])
    limit = time.monotonic() + int(os.environ.get('H3_JOB_TIMEOUT', '7200'))
    lost_connection = False
    history_request_errors = 0
    absent_after_recovery = 0
    while time.monotonic() < limit:
        if stop.is_set():
            raise RuntimeError('Stop requested')
        try:
            history = call(session, 'GET', url + '/history/' + prompt_id, timeout=15)
            history_request_errors = 0
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            # A brief API hiccup is NOT proof that the prompt has disappeared.
            # Allow reconnection before deciding to reroute the video.
            lost_connection = True
            history_request_errors += 1
            if history_request_errors <= 4:
                stop.wait(min(8, history_request_errors * 2))
                continue
            raise
        record = history.get(prompt_id)
        if not record and lost_connection:
            # On a ComfyUI restart /history becomes empty. Check /queue so a
            # still-running prompt is never unnecessarily submitted elsewhere.
            try:
                status_queue = call(session, 'GET', url + '/queue', timeout=10)
                live = status_queue.get('queue_running', []) + status_queue.get('queue_pending', [])
                still_queued = any(isinstance(r, (list, tuple)) and len(r) > 1
                                   and str(r[1]) == str(prompt_id) for r in live)
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
                lost_connection = True
                stop.wait(2)
                continue
            if not still_queued:
                absent_after_recovery += 1
                if absent_after_recovery >= 4:
                    raise LostPromptAfterRestart(f'ComfyUI restarted and lost prompt {prompt_id}')
            else:
                absent_after_recovery = 0
        if record:
            status = record.get('status', {})
            if status.get('status_str') == 'error' or status.get('completed') is False:
                raise RuntimeError('ComfyUI workflow error: ' + json.dumps(status.get('messages', []), ensure_ascii=False)[-2000:])
            if status.get('completed') or status.get('status_str') == 'success':
                source = locate_video(record, gpu, item['output_prefix'])
                if source is None:
                    raise RuntimeError('Original VHS_VideoCombine (1277) did not report an MP4 in GPU output')
                output.parent.mkdir(parents=True, exist_ok=True)
                tmp = output.with_name(output.name + '.copying')
                try:
                    shutil.copy2(source, tmp)
                    if tmp.stat().st_size <= 1000:
                        raise RuntimeError('VHS output MP4 is empty')
                    os.replace(tmp, output)
                finally:
                    tmp.unlink(missing_ok=True)
                return
        time.sleep(2)
    raise TimeoutError('One-pass workflow timeout: ' + prompt_id)


def recoverable_gpu_error(exc):
    """Only infrastructure failures merit a GPU cooldown and an automatic retry.

    A broken graph, missing node or invalid input must NOT cause endless retries.
    """
    if isinstance(exc, LostPromptAfterRestart):
        return True
    cause = exc
    seen = set()
    while cause is not None and id(cause) not in seen:
        seen.add(id(cause))
        if isinstance(cause, (requests.exceptions.ConnectionError, requests.exceptions.Timeout)):
            return True
        cause = cause.__cause__ or cause.__context__
    message = str(exc).lower()
    signs = (
        'connection refused', 'connection reset', 'connection aborted',
        'broken pipe', 'remote disconnected', 'server disconnected',
        'failed to establish a new connection', 'max retries exceeded',
        'cuda out of memory', 'cuda error: out of memory',
        'torch.outofmemoryerror', 'outofmemoryerror', 'allocation on device',
        'cudnn_status_alloc_failed', 'cuda error: an illegal memory access',
        'cuda error: unknown error', 'device-side assert triggered',
        'gpu is lost', 'unspecified launch failure', 'driver shutting down',
        'http 502', 'http 503', 'http 504',
    )
    return any(sign in message for sign in signs)


def work(run_id):
    """A healthy GPU alone consumes queue items; temporary failures get requeued.

    Other GPUs continue normally. A failed GPU does not take another task until
    it has cooled down AND its ComfyUI /system_stats endpoint responds again.
    No other part of the ComfyUI graph, sampling or file inputs is changed.
    """
    try:
        with LOCK:
            selected = ACTIVE['selected_gpus'][:]
            count = len(ACTIVE['tasks'])
        workers = [(idx + 1, COMFY[idx]) for idx in selected if idx < len(COMFY)]
        if not workers:
            raise RuntimeError('No ComfyUI GPUs selected')
        max_attempts = max(1, int(os.environ.get('H3_TASK_MAX_ATTEMPTS', '3')))
        cooldown_base = max(0.1, float(os.environ.get('H3_GPU_COOLDOWN_SEC', '45')))
        health_interval = max(0.1, float(os.environ.get('H3_GPU_HEALTH_INTERVAL_SEC', '4')))
        update_run(run_id, status='running', gpus=[g for g, _ in workers],
                   gpu_health={str(g): 'checking' for g, _ in workers})
        q = queue.Queue()
        for idx in range(count):
            q.put(idx)
        remaining = [count]
        scheduler_lock = threading.Lock()

        def left():
            with scheduler_lock:
                return remaining[0]

        def terminal():
            with scheduler_lock:
                remaining[0] -= 1

        def health(gpu, state):
            # Only persist actual transitions to limit disk writes.
            with LOCK:
                if ACTIVE is None or ACTIVE['id'] != run_id:
                    return
                h = ACTIVE.setdefault('gpu_health', {})
                if h.get(str(gpu)) == state:
                    return
                h[str(gpu)] = state
            persist()

        def worker(gpu, url):
            consecutive_faults = 0
            cooldown_until = 0.0
            with requests.Session() as s:
                while not ABORT.is_set():
                    if left() == 0:
                        break
                    # IMPORTANT: never dequeue while the ComfyUI process is
                    # restarting, absent or inside a GPU-fault cooldown.
                    if time.monotonic() < cooldown_until:
                        ABORT.wait(min(health_interval, cooldown_until - time.monotonic()))
                        continue
                    if not check_worker(url)['online']:
                        health(gpu, 'offline')
                        ABORT.wait(health_interval)
                        continue
                    health(gpu, 'ready')
                    try:
                        idx = q.get(timeout=0.5)
                    except queue.Empty:
                        continue
                    try:
                        if ABORT.is_set():
                            # Leave pending tasks for the final stop handling.
                            break
                        with LOCK:
                            item = copy.deepcopy(ACTIVE['tasks'][idx])
                        attempt = int(item.get('attempts', 0)) + 1
                        update_task(run_id, idx, 'running', gpu, '', attempts=attempt)
                        try:
                            execute_one(s, url, item, gpu, ABORT)
                        except Exception as exc:
                            if ABORT.is_set():
                                update_task(run_id, idx, 'skipped', gpu, 'User requested stop')
                                terminal()
                                continue
                            if recoverable_gpu_error(exc):
                                consecutive_faults += 1
                                cooldown = min(600, cooldown_base * 2 ** min(consecutive_faults - 1, 4))
                                cooldown_until = time.monotonic() + cooldown
                                health(gpu, 'cooldown')
                                if attempt < max_attempts:
                                    # Put the SAME video back in the queue for
                                    # this or any other healthy GPU.
                                    update_task(run_id, idx, 'pending', None,
                                                f'GPU{gpu}: temporary error, retry {attempt}/{max_attempts}: {exc}',
                                                attempts=attempt)
                                    q.put(idx)
                                else:
                                    update_task(run_id, idx, 'failed', gpu,
                                                f'GPU{gpu}: {max_attempts} attempts exhausted: {exc}',
                                                attempts=attempt)
                                    terminal()
                            else:
                                # Invalid workflow, missing model, wrong file etc.
                                # Retrying the same broken prompt cannot help.
                                update_task(run_id, idx, 'failed', gpu, exc, attempts=attempt)
                                terminal()
                        else:
                            consecutive_faults = 0
                            update_task(run_id, idx, 'done', gpu, '', attempts=attempt)
                            terminal()
                    finally:
                        q.task_done()
            health(gpu, 'stopped' if ABORT.is_set() else 'idle')

        threads = [threading.Thread(target=worker, args=(gpu, url), daemon=True)
                   for gpu, url in workers]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        if ABORT.is_set():
            for idx in range(count):
                with LOCK:
                    status = ACTIVE['tasks'][idx]['status']
                if status == 'pending':
                    update_task(run_id, idx, 'skipped', error='User requested stop')
        with LOCK:
            failed = sum(t['status'] == 'failed' for t in ACTIVE['tasks'])
        update_run(run_id, status='stopped' if ABORT.is_set() else 'finished',
                   failed=failed, finished=now())
    except Exception as exc:
        update_run(run_id, status='error', error=str(exc), finished=now())


def link_input(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() or dst.is_symlink():
        raise FileExistsError(dst)
    os.symlink(src, dst)


@app.before_request
def auth():
    if not PASSWORD:
        return None
    credentials = request.authorization
    if not credentials or credentials.password != PASSWORD:
        return Response('H3: password required', 401, {'WWW-Authenticate':'Basic realm="H3 Batch"'})
    return None


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/api/config')
def config():
    return jsonify({'roots': list(map(str, ROOTS)), 'home': str(HOME),
                    'mode': 'onepass', 'comfy': [check_worker(url) for url in COMFY]})


@app.get('/api/browse')
def browse():
    try:
        path = protected(request.args.get('path') or ROOTS[0])
        if not path.is_dir():
            raise ValueError('Not a directory')
        folders = sorted((x for x in path.iterdir() if x.is_dir() and not x.name.startswith('.')), key=natural_key)
        parent = str(path.parent) if any(path != r and r in path.parents for r in ROOTS) else None
        return jsonify({'path': str(path), 'parent': parent,
                        'dirs': [{'name':x.name,'path':str(x)} for x in folders],
                        'video_count':len(files_in(path, VIDEO_EXT)), 'image_count':len(files_in(path, IMAGE_EXT)),
                        'files':[{'name':x.name,'path':str(x)} for x in files_in(path, IMAGE_EXT)[:300]]})
    except (ValueError, OSError) as exc:
        return jsonify({'error':str(exc)}), 400


@app.post('/api/start')
def start():
    global ACTIVE
    try:
        payload = request.get_json(force=True)
        videos = files_in(payload.get('videos',''), VIDEO_EXT)
        bodies = files_in(payload.get('bodies',''), IMAGE_EXT)
        if not videos or not bodies:
            raise ValueError('Select non-empty video and body folders')
        if len(videos) > 10000:
            raise ValueError('More than 10000 videos')
        face_front = payload.get('face_front','').strip()
        face_side = payload.get('face_side','').strip()
        if not face_front or not face_side:
            raise ValueError('Specify BOTH Face front and Face 3/4')
        face_front = protected(face_front)
        face_side = protected(face_side)
        if not face_front.is_file() or face_front.suffix.lower() not in IMAGE_EXT:
            raise ValueError('Invalid front face: ' + str(face_front))
        if not face_side.is_file() or face_side.suffix.lower() not in IMAGE_EXT:
            raise ValueError('Invalid 3/4 face: ' + str(face_side))
        selected = sorted(set(int(x)-1 for x in payload.get('gpus',list(range(1,len(COMFY)+1)))))
        if not selected or any(x<0 or x>=len(COMFY) for x in selected):
            raise ValueError(f'Select a GPU between 1 and {len(COMFY)}')
        # Check exact source graph before changing any files.
        original_graph()
        preview_compat = payload.get('preview_compat', False)
        if type(preview_compat) is not bool:
            raise ValueError('preview_compat must be true or false')
        with LOCK:
            if ACTIVE and ACTIVE['status'] in ('running', 'starting'):
                raise ValueError('There is already an active batch; finish it first')
            ABORT.clear()
            run_id = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
            run_dir = HOME / 'runs' / run_id
            face_dir = COMFY_INPUT / 'h3_batch_onepass' / run_id
            face_dir.mkdir(parents=True, exist_ok=False)
            front_name = 'front'+face_front.suffix.lower()
            side_name = 'side'+face_side.suffix.lower()
            shutil.copy2(face_front, face_dir/front_name)
            shutil.copy2(face_side, face_dir/side_name)
            tasks = []
            for idx, video in enumerate(videos):
                body = bodies[idx % len(bodies)]
                stem = f'{idx+1:04d}_'+re.sub(r'[^A-Za-z0-9_-]', '_', video.stem)[:54]
                input_root = run_dir / '_input_links' / f'{idx+1:04d}'
                video_dir = input_root / 'video'
                body_dir = input_root / 'body'
                link_input(video, video_dir/video.name)
                link_input(body, body_dir/body.name)
                prefix = 'FINAL_VIDEOS/H3_ONEPASS_' + run_id + '_' + stem
                tasks.append({'video':str(video), 'body':str(body), 'face_front':str(face_front),
                              'face_side':str(face_side), 'video_dir':str(video_dir), 'body_dir':str(body_dir),
                              'face_front_rel':str(Path('h3_batch_onepass')/run_id/front_name),
                              'face_side_rel':str(Path('h3_batch_onepass')/run_id/side_name),
                              'output_prefix':prefix, 'preview_compat':preview_compat,
                              'final':str(run_dir/'FINAL_VIDEOS'/(stem+'.mp4')),
                              'status':'pending','gpu':None,'error':'','attempts':0,'updated':None})
            ACTIVE={'id':run_id,'mode':'onepass','status':'starting','created':now(),'finished':None,
                    'videos_dir':str(videos[0].parent),'bodies_dir':str(bodies[0].parent),
                    'selected_gpus':selected, 'gpus':[], 'tasks':tasks, 'failed':0, 'error':'',
                    'preview_compat':preview_compat}
        persist()
        threading.Thread(target=work,args=(run_id,),daemon=True).start()
        return jsonify({'ok':True,'run_id':run_id,'total':len(videos),'mode':'onepass'})
    except (ValueError, OSError, KeyError, TypeError) as exc:
        return jsonify({'error':str(exc)}),400


@app.get('/api/status')
def status():
    return jsonify({'run':snap()})


@app.post('/api/stop')
def stop():
    ABORT.set()
    return jsonify({'ok':True, 'message':'Running GPU prompts will finish, pending tasks skipped'})


@app.get('/api/disk')
def disk():
    d = shutil.disk_usage(HOME)
    return jsonify({'total_gb':round(d.total/1e9,1),'free_gb':round(d.free/1e9,1)})


if __name__ == '__main__':
    app.run(host=os.environ.get('H3_PANEL_HOST','127.0.0.1'),
            port=int(os.environ.get('H3_PANEL_PORT','18766')), threaded=True)
