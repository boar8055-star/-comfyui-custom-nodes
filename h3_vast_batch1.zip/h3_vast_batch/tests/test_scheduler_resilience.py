import os
import sys
import tempfile
import threading
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch

# Same Flask shim as test_scheduler.py
module = types.ModuleType('flask')
class Flask:
    def __init__(self, name): self.name = name
    def get(self, *args, **kwargs): return lambda f: f
    post = get
    before_request = get
module.Flask = Flask
module.Response = type('Response', (), {})
module.jsonify = lambda obj: obj
module.render_template = lambda name: name
module.request = None
sys.modules.setdefault('flask', module)
TEMP = tempfile.TemporaryDirectory()
os.environ['H3_BATCH_HOME'] = TEMP.name
os.environ['H3_ALLOWED_ROOTS'] = TEMP.name
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class ResilienceTests(unittest.TestCase):
    def setUp(self):
        server.ABORT.clear()
        self.env = patch.dict(os.environ, {
            'H3_GPU_HEALTH_INTERVAL_SEC': '0.1',
            'H3_GPU_COOLDOWN_SEC': '0.1',
            'H3_TASK_MAX_ATTEMPTS': '3',
        })
        self.env.start()
        tasks = [
            {'video': f'/tmp/clip_{i}.mp4', 'body': '/tmp/body.png',
             'final': f'{TEMP.name}/final_{i}.mp4',
             'status': 'pending', 'gpu': None, 'error': '', 'attempts': 0}
            for i in range(20)
        ]
        server.ACTIVE = {'id': 'resilience-run', 'status': 'starting',
                         'selected_gpus': [0, 1, 2, 3],
                         'gpus': [], 'tasks': tasks, 'mode': 'onepass'}

    def tearDown(self):
        self.env.stop()
        server.ABORT.clear()

    def test_initially_dead_gpu_never_receives_a_task(self):
        calls = []
        def check(url):
            return {'online': url != server.COMFY[3]}
        def run(session, url, item, gpu, stop):
            calls.append((item['video'], gpu))
            time.sleep(0.002)
        with patch.object(server, 'check_worker', side_effect=check), \
             patch.object(server, 'execute_one', side_effect=run):
            server.work('resilience-run')
        self.assertEqual(len(calls), 20)
        self.assertNotIn(4, [g for _, g in calls])
        self.assertTrue(all(x['status'] == 'done' for x in server.ACTIVE['tasks']))

    def test_gpu_oom_requeues_instead_of_cascading_failures(self):
        calls = []
        lock = threading.Lock()
        broken = [False]
        def run(session, url, item, gpu, stop):
            with lock:
                calls.append((item['video'], gpu))
                if gpu == 4 and not broken[0]:
                    broken[0] = True
                    raise RuntimeError('torch.OutOfMemoryError: CUDA out of memory')
            time.sleep(.01)
        with patch.object(server, 'check_worker', return_value={'online': True}), \
             patch.object(server, 'execute_one', side_effect=run):
            server.work('resilience-run')
        self.assertTrue(broken[0])
        self.assertEqual(len(calls), 21)  # exactly one prompt retried
        self.assertEqual(server.ACTIVE['failed'], 0)
        self.assertTrue(all(x['status'] == 'done' for x in server.ACTIVE['tasks']))
        self.assertEqual(sum(x['attempts'] == 2 for x in server.ACTIVE['tasks']), 1)

    def test_all_workers_offline_wait_until_stop_no_fail_cascade(self):
        th = threading.Thread(target=lambda: server.work('resilience-run'))
        with patch.object(server, 'check_worker', return_value={'online': False}):
            th.start()
            time.sleep(.2)
            self.assertTrue(all(x['status'] == 'pending' for x in server.ACTIVE['tasks']))
            server.ABORT.set()
            th.join(timeout=3)
        self.assertFalse(th.is_alive())
        self.assertEqual(server.ACTIVE['status'], 'stopped')
        self.assertEqual(server.ACTIVE['failed'], 0)
        self.assertTrue(all(x['status'] == 'skipped' for x in server.ACTIVE['tasks']))

    def test_malformed_workflow_is_not_retried(self):
        def bad(session, url, item, gpu, stop):
            raise RuntimeError('Missing ComfyUI node 12345')
        with patch.object(server, 'check_worker', return_value={'online': True}), \
             patch.object(server, 'execute_one', side_effect=bad):
            server.work('resilience-run')
        self.assertEqual(server.ACTIVE['failed'], 20)
        self.assertTrue(all(x['attempts'] == 1 for x in server.ACTIVE['tasks']))

if __name__ == '__main__': unittest.main()
