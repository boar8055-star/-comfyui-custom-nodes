import os
import sys
import tempfile
import threading
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch

# Lightweight Flask shim: tests do not launch a web server.
module = types.ModuleType('flask')
class Flask:
    def __init__(self, name): self.name=name
    def get(self,*args,**kwargs): return lambda f:f
    post=get
    before_request=get
module.Flask=Flask
module.Response=type('Response',(),{})
module.jsonify=lambda obj:obj
module.render_template=lambda name:name
module.request=None
sys.modules.setdefault('flask',module)
TEMP=tempfile.TemporaryDirectory()
os.environ['H3_BATCH_HOME']=TEMP.name
os.environ['H3_ALLOWED_ROOTS']=TEMP.name
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server

class OnepassSchedulerTests(unittest.TestCase):
    def test_four_gpu_one_full_workflow_per_video(self):
        events=[]
        mutex=threading.Lock()
        tasks=[]
        for idx in range(16):
            tasks.append({'video':f'/tmp/video{idx}.mp4','body':'/tmp/body.png',
                          'final':f'{TEMP.name}/FINAL_VIDEOS/{idx}.mp4',
                          'status':'pending','gpu':None,'error':''})
        server.ACTIVE={'id':'single-pass-test','status':'starting','selected_gpus':[0,1,2,3],
                       'gpus':[],'tasks':tasks,'mode':'onepass'}
        server.ABORT.clear()
        def fake_execute(session, url, item, gpu, stop):
            with mutex: events.append((item['video'],gpu,url))
            time.sleep(.01)
        with patch.object(server,'check_worker',side_effect=lambda url:{'online':True}), \
             patch.object(server,'execute_one',side_effect=fake_execute):
            server.work('single-pass-test')
        self.assertEqual(len(events),16)
        self.assertEqual(len({name for name,_,_ in events}),16)
        self.assertEqual({gpu for _,gpu,_ in events},{1,2,3,4})
        self.assertTrue(all(t['status']=='done' for t in server.ACTIVE['tasks']))
        self.assertEqual(server.ACTIVE['status'],'finished')

if __name__=='__main__': unittest.main()
