import copy
import hashlib
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from onepass import make_graph, original_graph, SOURCE_SHA256


class OriginalGraphTests(unittest.TestCase):
    def test_original_is_exact(self):
        data = (ROOT / 'workflow_api.json').read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), SOURCE_SHA256)
        self.assertEqual(len(original_graph()), 101)

    def test_only_file_inputs_differ(self):
        before = original_graph()
        after = make_graph('/a/body', '/a/video', 'front.png', 'side.png', 'FINAL_VIDEOS/one')
        self.assertEqual(set(before), set(after))
        allowed = {('11307','body_folder'), ('11307','video_folder'),
                   ('1242','image'), ('1243','image'), ('1269','image'),
                   ('1277','filename_prefix')}
        actual = set()
        for node_id, node in before.items():
            self.assertEqual(node['class_type'], after[node_id]['class_type'])
            self.assertEqual(node.get('_meta'), after[node_id].get('_meta'))
            self.assertEqual(set(node['inputs']), set(after[node_id]['inputs']))
            for name, value in node['inputs'].items():
                if after[node_id]['inputs'][name] != value:
                    actual.add((node_id,name))
        self.assertEqual(actual, allowed)
        self.assertEqual(before['1258']['inputs']['image'], ['12045', 0])
        self.assertEqual(after['1258']['inputs']['image'], ['12045', 0])
        self.assertEqual(after['11313']['inputs'], before['11313']['inputs'])
        self.assertEqual(after['1198']['inputs'], before['1198']['inputs'])
        self.assertEqual(after['1277']['inputs']['crf'], 14)
        self.assertEqual(after['1277']['inputs']['frame_rate'], 30)
        self.assertEqual(before, original_graph())

    def test_optional_preview_compat_only_one_link(self):
        standard = make_graph('/a','/b','front.png','side.png','FINAL_VIDEOS/one')
        compatible = make_graph('/a','/b','front.png','side.png','FINAL_VIDEOS/one',preview_compat=True)
        diffs = [(k, n) for k in standard for n in standard[k]['inputs']
                 if standard[k]['inputs'][n] != compatible[k]['inputs'][n]]
        self.assertEqual(diffs, [('1154','ref_images.ref_image_0')])
        self.assertEqual(compatible['1154']['inputs']['ref_images.ref_image_0'], ['1246',0])


if __name__ == '__main__': unittest.main()
