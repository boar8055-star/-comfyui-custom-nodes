#!/usr/bin/env python3
"""Check the original 101-node API graph against actual GPU ComfyUI services."""
import os
import requests
from onepass import original_graph

g = original_graph()
expected = {n['class_type'] for n in g.values()}
ports = [p.strip() for p in os.environ.get('H3_COMFY_PORTS','18188,18189,18190,18191').split(',') if p.strip()]
ready = 0
for number, port in enumerate(ports, 1):
    url = f'http://127.0.0.1:{port}'
    print(f'GPU{number}: {url}')
    try:
        stats = requests.get(url+'/system_stats',timeout=5)
        stats.raise_for_status()
        types = requests.get(url+'/object_info',timeout=45)
        types.raise_for_status()
        offered = types.json()
        missing = expected - set(offered)
        if missing:
            print('  Missing node types:', ', '.join(sorted(missing)))
        else:
            print('  All', len(expected), 'original node types registered')
            ready += 1
        if not offered.get('PreviewImage',{}).get('output'):
            print('  NOTICE: original graph connects 1154 to PreviewImage sink 1247.')
            print('  To run this standard ComfyUI, explicitly enable PreviewImage compatibility in panel.')
    except Exception as e:
        print('  Unavailable:', str(e))
print(f'Ready: {ready}/{len(ports)}')
raise SystemExit(0 if ready else 1)
