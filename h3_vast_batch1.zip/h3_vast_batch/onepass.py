"""Run a user's entire original ComfyUI API graph ONCE per source video.

The stored workflow_api.json is byte-identical to the uploaded original.
The only per-prompt substitutions are input selection and output prefix. A
PreviewImage edge compatibility fix can be enabled explicitly, since standard
ComfyUI's PreviewImage has no IMAGE output.
"""
import copy
import hashlib
import json
from pathlib import Path

WORKFLOW_PATH = Path(__file__).with_name('workflow_api.json')
SOURCE_SHA256 = '1ae8c74ab65e445b796e6edb0ab31ce0b6d4fbdec5d1a4ee754cfadc7b6059f6'


def original_graph():
    raw = WORKFLOW_PATH.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SOURCE_SHA256:
        raise ValueError('Original workflow_api.json changed: refusing to run modified graph')
    graph = json.loads(raw)
    if not isinstance(graph, dict) or len(graph) != 101:
        raise ValueError('Original API graph does not contain 101 nodes')
    return graph


def make_graph(body_dir, video_dir, front_ref, side_ref, prefix, *, preview_compat=False):
    g = copy.deepcopy(original_graph())
    # Only dynamic inputs; all original node classes, algorithms, params and
    # connections are otherwise kept exactly as supplied.
    g['11307']['inputs']['body_folder'] = str(body_dir)
    g['11307']['inputs']['video_folder'] = str(video_dir)
    g['1242']['inputs']['image'] = str(front_ref)
    g['1243']['inputs']['image'] = str(side_ref)
    g['1269']['inputs']['image'] = str(front_ref)
    g['1277']['inputs']['filename_prefix'] = str(prefix)
    if preview_compat:
        # Necessary only on standard ComfyUI: PreviewImage has no output.
        # The source JSON remains untouched. Both nodes receive SAME image.
        assert g['1154']['inputs']['ref_images.ref_image_0'] == ['1247', 0]
        assert g['1247']['inputs']['images'] == ['1246', 0]
        g['1154']['inputs']['ref_images.ref_image_0'] = ['1246', 0]
    return g
