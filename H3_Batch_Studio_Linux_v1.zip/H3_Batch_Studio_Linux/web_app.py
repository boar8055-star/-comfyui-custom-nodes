#!/usr/bin/env python3
"""Linux/headless browser GUI for H3 Batch Studio. Python stdlib only.

Security: binds localhost by default. Listening on 0.0.0.0 REQUIRES
H3_STUDIO_TOKEN; send it as X-H3-Token header from the browser interface.
"""
from __future__ import annotations
import argparse
import datetime
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from batch_core import HERE, BatchError, read_catalog, pair_items, queue_batch, request_json

CATALOGS = HERE / 'catalogs'
PHOTOS = HERE / 'photos'
MAX_ZIP = 1024*1024*1024 * 2
MAX_UNPACKED = 1024*1024*1024 * 4
CATALOGS.mkdir(exist_ok=True)
PHOTOS.mkdir(exist_ok=True)

STATE = {'busy':False, 'action':'idle', 'message':'Готово к работе', 'stats':None, 'events':[], 'last_run':None}
STATE_LOCK = threading.Lock()
STOP = threading.Event()
SETTINGS = HERE/'settings_linux.json'
DEFAULTS = {'url':'http://127.0.0.1:8188',
            'photos':str(PHOTOS),
            'catalog':str(CATALOGS/'miami_50_scenarios.json'),
            'workflow':str(HERE/'h3_ui_template.json'),
            'duration':15,
            'skip_missing':True,
            'remote':False}
TOKEN = ''  # No additional login; use Vast Portal access control


def state_set(**kwargs):
    with STATE_LOCK: STATE.update(kwargs)


def state_log(message):
    with STATE_LOCK:
        STATE['events'].append(f'[{datetime.datetime.now():%H:%M:%S}] {message}')
        STATE['events'] = STATE['events'][-250:]


def state_get():
    with STATE_LOCK: return json.loads(json.dumps(STATE,ensure_ascii=False))


def get_settings():
    s = DEFAULTS.copy()
    if SETTINGS.exists():
        try:
            saved=json.loads(SETTINGS.read_text(encoding='utf-8'))
            for name in DEFAULTS:
                if name in saved: s[name]=saved[name]
        except Exception: pass
    return s


def clean_settings(p):
    result=get_settings()
    for name in DEFAULTS:
        if name in p: result[name]=p[name]
    result['duration']=int(result['duration'])
    if result['duration'] < 2 or result['duration'] > 20:
        raise BatchError('Длительность от 2 до 20 секунд')
    for name in ('photos','catalog','workflow','url'):
        if not isinstance(result[name],str) or not result[name].strip():
            raise BatchError(f'Заполни поле {name}')
    for name in ('skip_missing','remote'):
        result[name]=bool(result[name])
    return result


def inspect(p):
    _, items=read_catalog(p['catalog'])
    paired, missing, duplicates=pair_items(items, p['photos'], allow_remote=p['remote'])
    stats={'total':len(items),'paired':len(paired),'missing':len(missing),
           'missing_ids':missing[:100], 'duplicates':duplicates[:100],
           'preview':[{'id':a['id'], 'photo':Path(a['photo_path']).name if a.get('photo_path') else '[ComfyUI output]',
                       'title':a.get('title','')} for a in paired[:100]]}
    return paired, stats


def run_background(p, action):
    try:
        state_log(f'Старт: {action}. Фото: {p["photos"]}; каталог: {p["catalog"]}')
        paired,stats=inspect(p)
        state_set(stats=stats)
        state_log(f'Каталог: {stats["total"]}; пар найдено: {stats["paired"]}; отсутствует: {stats["missing"]}')
        for msg in stats['duplicates'][:5]:state_log('Несколько фото: '+msg)
        if not paired:raise BatchError('Нет ни одной пары фото/видеопромпт. Проверь имена PNG и ID в JSON.')
        if action == 'check':
            ledger=queue_batch(p['url'],p['workflow'],paired,seconds=p['duration'],dry_run=True,emit=state_log)
            state_set(last_run=ledger['run_id'],message='Пары проверены, ничего не отправлено')
            return
        if action=='all' and stats['missing'] and not p['skip_missing']:
            raise BatchError('Не найдены фотографии: '+', '.join(stats['missing_ids'][:25]))
        ledger=queue_batch(p['url'],p['workflow'],paired,seconds=p['duration'],limit=1 if action=='one' else 0,
                           dry_run=False,stop_event=STOP,emit=state_log)
        state_set(last_run=ledger['run_id'],message=f'Отправка: {ledger["status"]}; run={ledger["run_id"]}')
    except Exception as e:
        state_log('ОШИБКА: '+str(e))
        state_set(message='Ошибка: '+str(e))
    finally:
        state_set(busy=False,action='idle')


HTML = r'''<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MiniMax H3 Batch Studio · Linux</title>
<style>
:root{font-family:Inter,system-ui,Arial,sans-serif;color-scheme:dark;background:#101823;color:#e7eff8}
*{box-sizing:border-box}body{margin:0;padding:20px}.wrap{max-width:1080px;margin:auto}
h1{font-size:28px;margin:0 0 8px}h2{font-size:17px;margin:22px 0 12px}
p,.sub{color:#aab9ca}.panel{background:#192433;border:1px solid #304057;border-radius:16px;padding:20px;margin:16px 0}
label{display:block;font-size:13px;color:#c6d1df;margin:12px 0 5px}input,select{font:inherit;color:#f6faff;background:#0f1826;border:1px solid #405169;border-radius:9px;padding:11px;width:100%}
.two{display:grid;grid-template-columns:1fr 1fr;gap:16px}.btns{display:flex;flex-wrap:wrap;gap:10px;margin-top:20px}button{font:inherit;background:#2e4565;color:white;border:1px solid #486389;border-radius:10px;padding:12px 17px;cursor:pointer}button.main{background:#277bd3;border-color:#428cde;font-weight:700}button.red{background:#683e46;border-color:#98606c}button:disabled{opacity:.45;cursor:not-allowed}
.small{font-size:12px;color:#9aaebe}pre{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.5;font-family:ui-monospace,Consolas,monospace;font-size:12px;background:#0b131e;border-radius:9px;padding:16px;min-height:170px;max-height:410px;overflow:auto}
.inline{display:flex;gap:12px;align-items:center;margin-top:12px}.inline input{width:auto}.upload{border:1px dashed #3c5370;padding:12px;border-radius:10px;margin-top:14px}.tag{display:inline-block;background:#26394e;border-radius:20px;padding:6px 11px;font-size:12px;margin-right:6px}
@media(max-width:700px){.two{grid-template-columns:1fr}.panel{padding:15px}h1{font-size:22px}}
</style></head><body><main class="wrap">
<p class="sub">LINUX • /workspace/ComfyUI • H3 DIRECTOR + SAGEATTENTION + RIFE</p>
<h1>MiniMax H3 · Batch Studio</h1>
<p>Фото Qwen → соответствующий video_prompt → очередь ComfyUI. Не нужно GUI/Tkinter на сервере.</p>
<div class="panel">
<span class="tag">Picture 1 = PNG первого кадра</span><span class="tag">1–50 Reels</span><span class="tag">Выход: 1080×1920 / 30 FPS</span>
<div id="authbox" style="display:none"><label>Токен доступа (H3_STUDIO_TOKEN для публичного порта)</label><input id="token" type="password" placeholder="Токен для API"></div>
<div class="two"><div><label>1. Папка с фото НА LINUX</label><input id="photos" spellcheck="false"></div>
<div><label>2. Каталог промптов JSON на Linux</label><select id="preset"></select><input id="catalog" spellcheck="false" style="margin-top:8px"></div></div>
<div class="two"><div><label>3. URL MiniMax H3 ComfyUI на Linux</label><input id="url" spellcheck="false"></div>
<div><label>4. H3 workflow</label><input id="workflow" spellcheck="false"></div></div>
<div class="two"><div><label>Длительность (сек)</label><select id="duration"><option>5</option><option>8</option><option>10</option><option>12</option><option selected>15</option></select></div>
<div><label class="inline"><input id="skip_missing" type="checkbox" checked> Пропускать сценарии без PNG</label>
<label class="inline"><input id="remote" type="checkbox"> Забрать отсутствующие фото из Qwen manifest через /view (только если это тот же ComfyUI)</label></div></div>
<div class="btns"><button onclick="go('check')">Проверить пары</button><button class="main" onclick="go('one')">▶ QUEUE 1 VIDEO</button><button class="main" onclick="go('all')">▶ QUEUE ALL VIDEOS</button><button class="red" onclick="stop()">Стоп отправки</button><button onclick="connection()">Проверить ComfyUI</button></div>
</div>
<div class="panel"><h2>Перенести фото и каталог с Windows на Linux</h2>
<div class="upload"><label>ZIP с готовыми PNG/JPG/WEBP (можно упаковать папку с Windows целиком)</label>
<input id="zipfile" type="file" accept=".zip"><button style="margin-top:10px" onclick="uploadZip()">Загрузить ZIP на Linux</button><p class="small">Распакуются только изображения в папку photos/import_... . Размер ZIP до 2 ГБ.</p></div>
<div class="upload"><label>Каталог JSON или Qwen manifest.json с video_prompt</label><input id="catalogfile" type="file" accept=".json,application/json"><button style="margin-top:10px" onclick="uploadCatalog()">Загрузить JSON-каталог на Linux</button></div>
</div>
<div class="panel"><h2>Статус</h2><p id="status">Подключение…</p><div id="stats" class="small"></div><pre id="log">Логи появятся здесь</pre><p class="small">Результаты: /workspace/ComfyUI/output/MiniMaxH3Batch/&lt;run-id&gt;/ · отчёт в папке runs/</p></div>
</main><script>
let defaults=false, busy=false;
const $=x=>document.getElementById(x);
function headers(extra={}){return {...extra,...($('token')&&$('token').value?{'X-H3-Token':$('token').value}:{})}}
async function call(path,data){let r=await fetch(path,{method:'POST',headers:headers({'Content-Type':'application/json'}),body:JSON.stringify(data)});let x=await r.json();if(!r.ok)throw new Error(x.error||r.status);return x}
function values(){return {url:$('url').value,photos:$('photos').value,catalog:$('catalog').value,workflow:$('workflow').value,duration:Number($('duration').value),skip_missing:$('skip_missing').checked,remote:$('remote').checked}}
async function initialize(){try{let r=await fetch('/api/config',{headers:headers()});let x=await r.json();if(r.status===401){$('authbox').style.display='block';throw new Error('Введи H3_STUDIO_TOKEN и нажми Enter')}if(!r.ok)throw new Error(x.error||r.status);if(x.needs_token)$('authbox').style.display='block';if(!defaults){for(let key of ['url','photos','catalog','workflow','duration'])$(key).value=x.settings[key];for(let key of ['skip_missing','remote'])$(key).checked=x.settings[key];let sel=$('preset');sel.innerHTML='<option value="">— Выбери каталог —</option>';for(let c of x.catalogs){let o=document.createElement('option');o.value=c.path;o.textContent=c.name;sel.appendChild(o)}sel.onchange=()=>{if(sel.value)$('catalog').value=sel.value};defaults=true;} }catch(e){$('status').textContent='Ошибка: '+e.message;}}
async function go(action){if(busy){alert('Сначала дождись окончания текущей операции');return}if(action!=='check'&&!confirm(action==='one'?'Добавить ОДНО видео в очередь H3?':'Добавить ВСЕ найденные видео в очередь H3?'))return;try{let r=await call('/api/start',{...values(),action});$('status').textContent=r.message||'Запущено';}catch(e){alert(e.message)}}
async function stop(){try{await call('/api/stop',{});}catch(e){alert(e.message)}}
async function connection(){try{let r=await call('/api/connection',{url:$('url').value});alert(r.message)}catch(e){alert(e.message)}}
async function uploadZip(){let f=$('zipfile').files[0];if(!f){alert('Выбери ZIP');return}try{let r=await fetch('/api/upload-zip',{method:'POST',headers:headers({'Content-Type':'application/zip'}),body:f});let x=await r.json();if(!r.ok)throw Error(x.error);$('photos').value=x.photos;alert('Загружено фотографий: '+x.count+'\nПапка: '+x.photos);}catch(e){alert('Ошибка ZIP: '+e.message)}}
async function uploadCatalog(){let f=$('catalogfile').files[0];if(!f){alert('Выбери JSON');return}try{let r=await fetch('/api/upload-catalog',{method:'POST',headers:headers({'Content-Type':'application/json'}),body:f});let x=await r.json();if(!r.ok)throw Error(x.error);$('catalog').value=x.catalog;alert('Загружено промптов: '+x.count);}catch(e){alert('Ошибка JSON: '+e.message)}}
async function poll(){try{let r=await fetch('/api/state',{headers:headers()});let s=await r.json();if(!r.ok)throw Error(s.error||r.status);busy=s.busy;$('status').textContent=s.message+(busy?' · Выполняется: '+s.action:'');$('stats').textContent=s.stats?`В каталоге: ${s.stats.total} | Найдено пар: ${s.stats.paired} | Без фото: ${s.stats.missing}`:'';let l=$('log');let current=(s.events||[]).join('\n');if(l.textContent!==current){l.textContent=current||'Нет записей';l.scrollTop=l.scrollHeight;}}catch(e){$('status').textContent='Статус недоступен: '+e.message}}
}
$('token').addEventListener('change',()=>{initialize();poll()});$('token').addEventListener('keydown',e=>{if(e.key==='Enter'){initialize();poll()}});initialize();setInterval(poll,1200);poll();
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = 'H3BatchLinux/1.0'

    def log_message(self, fmt, *args):
        if self.path not in ('/api/state','/api/config'):
            super().log_message(fmt,*args)

    def json_reply(self, data, code=200):
        raw=json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers();self.wfile.write(raw)

    def auth(self):
        if TOKEN and self.headers.get('X-H3-Token') != TOKEN:
            self.json_reply({'error':'Требуется H3_STUDIO_TOKEN (введи токен на странице)'},401)
            return False
        return True

    def get_body(self,limit=300_000):
        size=int(self.headers.get('Content-Length','0'))
        if not (0<size<=limit):raise BatchError(f'Размер запроса вне диапазона (макс {limit} байт)')
        return self.rfile.read(size)

    def post_json(self):
        try:return json.loads(self.get_body())
        except (json.JSONDecodeError, UnicodeDecodeError) as e:raise BatchError('Некорректный JSON') from e

    def do_GET(self):
        path=urlsplit(self.path).path
        if path=='/':
            raw=HTML.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('X-Frame-Options','DENY')
            self.send_header('Cache-Control','no-store')
            self.send_header('Content-Length',str(len(raw))); self.end_headers();self.wfile.write(raw)
            return
        if not self.auth():return
        if path=='/api/state':self.json_reply(state_get());return
        if path=='/api/config':
            cats=sorted([{'name':p.name,'path':str(p)} for p in CATALOGS.glob('*.json')],key=lambda p:p['name'])
            self.json_reply({'settings':get_settings(),'catalogs':cats,'needs_token':bool(TOKEN)});return
        self.json_reply({'error':'not found'},404)

    def do_POST(self):
        if not self.auth():return
        path=urlsplit(self.path).path
        try:
            if path=='/api/start':
                raw=self.post_json()
                action=raw.pop('action',None)
                if action not in ('check','one','all'):raise BatchError('Некорректное действие')
                p=clean_settings(raw)
                with STATE_LOCK:
                    if STATE['busy']:raise BatchError('Уже выполняется другая задача')
                    STATE.update(busy=True,action=action,message='Начинаю '+action,stats=None)
                SETTINGS.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
                STOP.clear()
                th=threading.Thread(target=run_background,args=(p,action),daemon=True)
                th.start()
                self.json_reply({'ok':True,'message':'Отправка начата, смотри статус ниже'});return
            if path=='/api/stop':
                STOP.set()
                state_log('Остановка запрошена: текущая загрузка завершится, новых заданий не будет')
                self.json_reply({'ok':True});return
            if path=='/api/connection':
                p=self.post_json()
                info=request_json(p.get('url',''),'/system_stats',timeout=8)
                self.json_reply({'message':'Соединение с ComfyUI установлено. GPU: '+', '.join(d.get('name','GPU') for d in info.get('devices',[]))});return
            if path=='/api/upload-zip':
                if state_get()['busy']:raise BatchError('Дождись окончания отправки')
                size=int(self.headers.get('Content-Length','0'))
                if not (0<size<=MAX_ZIP):raise BatchError('ZIP должен быть меньше 2 ГБ')
                import tempfile
                with tempfile.NamedTemporaryFile(suffix='.zip',delete=False,dir=str(PHOTOS)) as tmp:
                    tmp_name=tmp.name
                    left=size
                    while left:
                        block=self.rfile.read(min(left,1024*1024))
                        if not block:raise BatchError('Загрузка ZIP прервалась')
                        tmp.write(block);left-=len(block)
                imported=PHOTOS/('import_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:5])
                try:
                    count=0;bytes_total=0
                    with zipfile.ZipFile(tmp_name) as z:
                        candidates=[m for m in z.infolist() if not m.is_dir() and Path(m.filename).suffix.lower() in ('.png','.jpg','.jpeg','.webp')]
                        if not candidates:raise BatchError('В ZIP нет PNG/JPG/WEBP')
                        imported.mkdir()
                        for i,member in enumerate(candidates):
                            bytes_total+=member.file_size
                            if bytes_total>MAX_UNPACKED:raise BatchError('Слишком много распакованных фото (>4 ГБ)')
                            name=Path(member.filename.replace('\\','/')).name
                            if not name:continue
                            target=imported/name
                            if target.exists():target=imported/f'{target.stem}_dup{i}{target.suffix}'
                            with z.open(member) as rd,target.open('wb') as out:
                                while True:
                                    block=rd.read(1024*1024)
                                    if not block:break
                                    out.write(block)
                            count+=1
                    state_log(f'Импортированы фотографии: {count} в {imported}')
                    self.json_reply({'count':count,'photos':str(imported)})
                except Exception:
                    if imported.exists():
                        import shutil;shutil.rmtree(imported,ignore_errors=True)
                    raise
                finally:Path(tmp_name).unlink(missing_ok=True)
                return
            if path=='/api/upload-catalog':
                body=self.get_body(limit=12*1024*1024)
                data=json.loads(body.decode('utf-8-sig'))
                if not isinstance(data,dict) or not isinstance(data.get('items'),list):
                    raise BatchError('JSON должен содержать items')
                path=CATALOGS/('uploaded_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:4]+'.json')
                path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
                try: _,items=read_catalog(path)
                except Exception:
                    path.unlink(missing_ok=True);raise
                state_log('Загружен новый каталог: '+str(path))
                self.json_reply({'catalog':str(path),'count':len(items)});return
            self.json_reply({'error':'not found'},404)
        except Exception as e:
            self.json_reply({'error':str(e)},400)


def main():
    parser=argparse.ArgumentParser(description='MiniMax H3 Batch Studio for Linux (web UI)')
    parser.add_argument('--host',default=os.environ.get('H3_STUDIO_HOST','127.0.0.1'))
    parser.add_argument('--port',type=int,default=int(os.environ.get('H3_STUDIO_PORT','8766')))
    args=parser.parse_args()
    if args.host not in ('127.0.0.1','localhost','::1') and not TOKEN:
        parser.error('Для доступа через 0.0.0.0 задай H3_STUDIO_TOKEN, например export H3_STUDIO_TOKEN="long-secret"')
    server=ThreadingHTTPServer((args.host,args.port),Handler)
    print(f'H3 Batch Studio Linux: http://{args.host}:{args.port}',flush=True)
    print('ComfyUI по умолчанию: http://127.0.0.1:8188',flush=True)
    print('Фото по умолчанию: '+str(PHOTOS),flush=True)
    try: server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt: pass
    finally:server.server_close()

if __name__=='__main__':main()
