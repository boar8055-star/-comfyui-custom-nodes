"""MiniMax H3 Director batch launcher. Python 3.10+, no third-party dependencies.

Input: local PNG/JPG/WEBP whose filenames begin with item ID; either Qwen
catalog JSON or Qwen run manifest.json containing items + video_prompt.
Output: per-item ComfyUI /prompt jobs, SaveVideo filenames prefixed by ID.

Designed against a supplied AIMixer MiniMaxH3Director UI workflow and its
embedded timeline_data schema. Offline graph tests live in tests/.
"""
from __future__ import annotations

import copy
import datetime
import json
import mimetypes
import os
from pathlib import Path
import random
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid

HERE = Path(__file__).resolve().parent
INPUT_EXT = {'.png', '.jpg', '.jpeg', '.webp'}
MAX_IMAGE_BYTES = 60 * 1024 * 1024


class BatchError(RuntimeError):
    pass


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def safe_id(raw):
    value = str(raw or '').strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{2,40}', value):
        raise BatchError(f'Неверный ID в каталоге: {value!r}')
    return value


def read_catalog(path):
    data = read_json(path)
    if not isinstance(data, dict) or not isinstance(data.get('items'), list):
        raise BatchError('JSON должен содержать массив items (каталог Qwen или manifest.json)')
    if not data['items']:
        raise BatchError('В каталоге нет сценариев')
    items = []
    seen = set()
    for raw in data['items']:
        id_ = safe_id(raw.get('id'))
        prompt = raw.get('video_prompt', '')
        if not isinstance(prompt, str) or not prompt.strip():
            raise BatchError(f'В {id_} отсутствует video_prompt')
        if id_.lower() in seen:
            raise BatchError(f'Повтор ID: {id_}')
        seen.add(id_.lower())
        items.append({'id': id_, 'video_prompt': prompt, 'images': raw.get('images') or [],
                      'title': raw.get('title') or '', 'duration_seconds': raw.get('duration_seconds') or 15})
    return data, items


def scan_photos(folder):
    """Return local files recursively; no recursion if folder does not exist."""
    if not folder:
        return []
    root = Path(folder)
    if not root.is_dir():
        raise BatchError(f'Папка с фото не найдена: {root}')
    return [p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in INPUT_EXT]


def filename_matches_id(filename, id_):
    stem = Path(filename).stem
    # NR001_00001_.png; MIA001.png; batch_xyz_MIA001.png; avoid NR001 vs NR0010.
    return bool(re.search(r'(?i)(?:^|[_\-\s])' + re.escape(id_) + r'(?=$|[_\-\s])', stem))


def matching_photos(files, id_):
    candidates = [p for p in files if filename_matches_id(p.name, id_)]
    # Keep the newest version if several Qwen iterations are in the same folder.
    return sorted(candidates, key=lambda p: (p.stat().st_mtime_ns, p.name.lower()), reverse=True)


def pair_items(items, folder=None, allow_remote=False):
    photos = scan_photos(folder)
    paired, missing, extras = [], [], []
    for item in items:
        options = matching_photos(photos, item['id'])
        chosen = options[0] if options else None
        remote = None
        if not chosen and allow_remote:
            imgs = item.get('images') or []
            for img in imgs:
                if isinstance(img, dict) and img.get('filename') and img.get('type', 'output') in ('output', 'input', 'temp'):
                    remote = img; break
        if not chosen and not remote:
            missing.append(item['id'])
        else:
            paired.append({**item, 'photo_path': str(chosen) if chosen else None,
                           'remote_image': remote, 'alternates': [str(p) for p in options[1:]]})
        if len(options) > 1:
            extras.append(f"{item['id']}: {len(options)} PNG/JPG, выбран {options[0].name}")
    return paired, missing, extras


def duration_frames(seconds, fps=24):
    if not 2 <= seconds <= 20:
        raise BatchError('Длительность должна быть от 2 до 20 секунд')
    if fps != 24:
        raise BatchError('В этой версии MiniMax H3 предусмотрена генерация при 24 FPS')
    # Uploaded source graph: 243 frames ~= 10 seconds at 24 FPS.
    # Use 5+8k-shaped lengths (363 = 5+8*44.75? Non valid); prefer 361=5+8*44.
    # This is 15.0 sec at 24 FPS and satisfies (frames-1)%4 == 0.
    target = round(seconds * fps) + 1
    return 4 * round((target - 1) / 4) + 1


def make_ref(filename):
    # Upload images to ComfyUI input ROOT so every Director revision resolves them.
    return {'index': 0, 'imageFile': filename, 'fileName': filename, 'type': 'input', 'subfolder': ''}


def create_clean_timeline(prompt, uploaded_name, total_frames=361, fps=24, width=768, height=1376, ref_size=1376):
    """Fresh Director v5 timeline: no stale Video 1, Picture 2, or unrelated prompts."""
    ref = make_ref(uploaded_name)
    mode = 'r2v — 参考主体生视频(Reference to Video)'
    seg = {
        'id': 's0', 'start': 0, 'length': total_frames,
        'frameCount': total_frames, 'durationSec': round((total_frames - 1) / fps, 3),
        'prompt': prompt, 'negativePrompt': '', 'taskType': '',
        'refs': [ref], 'refAudios': [], 'refVideos': [],
        'genImage': {'imageFile': '', 'fileName': ''},
        'startImage': None, 'endImage': None,
        'continuityFromPrev': False, 'refImageSize': 'match', 'loras': [],
        'referenceVideo': {'videoFile': '', 'fileName': '', 'type': 'input', 'subfolder': ''},
        '_videoFrameCount': total_frames, 'previewFps': fps,
    }
    global_common = {'commonEnabled': False, 'commonCollapsed': False,
                     'prompt': '', 'refs': [], 'refAudios': [], 'refVideos': []}
    return {
        'version': 5, 'editMode': 'segment', 'timelineMode': 'prompt_batch',
        'totalFrames': total_frames, 'frameRate': fps,
        'width': width, 'height': height, 'refMaxSize': ref_size,
        'output': {'mode': 'fixed', 'aspectRatio': '9:16 (竖屏)',
                   'megapixels': round(width * height / 1_000_000, 3),
                   'multiple': 32, 'longEdge': ref_size,
                   'width': width, 'height': height,
                   'maxExportFrames': 0, 'exportMode': 'all', 'audioMode': 'generate',
                   'exportSourceImages': False, 'exportPreFaceRefine': False,
                   'refImageSize': 'match',
                   'continuityEnabled': False, 'continuityOverlapFrames': 5,
                   'continuityMode': 'guide', 'continuityRedraw': 0.1,
                   'continuityKeepTail': True},
        'videoClips': [],
        'video': {'fileName': '', 'videoFile': '', 'subfolder': '', 'type': 'input',
                  'frames': [], 'frameMap': [], 'sourceFrameCount': 0, 'deletedSourceRanges': []},
        'global': {'taskType': mode, 'prompt': '', 'refs': [],
                   'referenceVideo': {'videoFile': '', 'fileName': '', 'subfolder': '', 'type': 'input'},
                   'continuousReference': False, 'genImage': {'imageFile': ''},
                   'refAudios': [], 'refVideos': [], 'commonEnabled': False, 'commonCollapsed': False},
        'segments': [seg],
        'gen': {'defaultFrameCount': total_frames},
        'runSelectEnabled': False, 'runSelection': [], 'liveTaePreview': False,
        'batchDetailMode': 'solo',
        'batchWorkspaces': {
            'r2v': {'selectedIndex': 0, 'editMode': 'segment', 'runSelectEnabled': False,
                    'runSelection': [], 'segments': [copy.deepcopy(seg)],
                    'globalCommon': copy.deepcopy(global_common)},
            'i2v': {'selectedIndex': 0, 'editMode': 'segment', 'runSelectEnabled': False,
                    'runSelection': [], 'segments': [],
                    'globalCommon': copy.deepcopy(global_common)},
        }
    }


def build_clean_ui(src):
    """Make a sanitized UI template (without original stale contents)."""
    wf = copy.deepcopy(src)
    by_type = {}
    for n in wf.get('nodes', []):
        by_type.setdefault(n['type'], []).append(n)
    if not by_type.get('MiniMaxH3Director'):
        raise BatchError('В workflow не найдена нода MiniMaxH3Director')
    if not by_type.get('SaveVideo'):
        raise BatchError('В workflow не найдена нода SaveVideo')
    n = by_type['MiniMaxH3Director'][0]
    named = n.get('widgets_values_named', {})
    if not named:
        raise BatchError('Нода MiniMaxH3Director не содержит widgets_values_named')
    # Replace old text recursively at the only source: old timeline_data and global prompt.
    tl = create_clean_timeline('A woman smiles at the camera and waves.', 'H3_PLACEHOLDER.png', 361)
    named['global_prompt'] = ''
    named['task_type'] = 'r2v — 参考主体生视频(Reference to Video)'
    named['total_frames'] = 361
    named['timeline_data'] = json.dumps(tl, ensure_ascii=False, separators=(',', ':'))
    values=n.get('widgets_values',[])
    if len(values) > 10:
        values[0] = named['task_type']
        values[1] = named['global_prompt']
        values[10] = 361
        values[11] = named['timeline_data']
    return wf


def convert_ui_to_api(src):
    """Convert the actual uploaded UI graph using source links + named widgets."""
    wf = build_clean_ui(src)
    nodes = {str(n['id']): n for n in wf['nodes']}
    link_by_id = {int(x[0]): x for x in wf.get('links', [])}
    if not any(n['type'] == 'SaveVideo' for n in nodes.values()):
        raise BatchError('Отсутствует SaveVideo')
    api = {}
    for id_, node in nodes.items():
        if node['type'] == 'MarkdownNote':
            continue
        inputs = dict(node.get('widgets_values_named') or {})
        # UI-only fields are not graph inputs; drop by name.
        inputs.pop('control_after_generate', None)
        inputs.pop('minimax_director_ui', None)
        for port in node.get('inputs', []):
            if port.get('link') is None:
                continue
            link = link_by_id.get(port['link'])
            if not link:
                raise BatchError(f'Нода {id_}: отсутствует link {port["link"]}')
            source_id, source_slot = str(link[1]), int(link[2])
            if source_id not in nodes:
                raise BatchError(f'Нет исходной ноды {source_id}')
            inputs[port['name']] = [source_id, source_slot]
        api[id_] = {'class_type': node['type'], 'inputs': inputs,
                    '_meta': {'title': node.get('title') or node['type']}}
    required = {'5':'MiniMaxH3Director', '7':'SaveVideo', '14':'PathchSageAttentionKJ'}
    for id_, t in required.items():
        if id_ not in api or api[id_]['class_type'] != t:
            raise BatchError(f'Ожидалась нода {id_}: {t}, получено {api.get(id_,{})}')
    return api


def prepare_job(base_api, video_prompt, image_name, reel_id, run_id, seconds=15, seed=None):
    result = copy.deepcopy(base_api)
    n = result['5']['inputs']
    old = json.loads(n['timeline_data'])
    fps = int(n.get('frame_rate', 24))
    frame_count = duration_frames(seconds, fps)
    n['task_type'] = 'r2v — 参考主体生视频(Reference to Video)'
    n['global_prompt'] = ''
    n['total_frames'] = frame_count
    n['seed'] = int(seed if seed is not None else random.SystemRandom().randint(1, 2**53 - 1))
    n['timeline_data'] = json.dumps(create_clean_timeline(video_prompt, image_name,
        total_frames=frame_count, fps=fps,
        width=int(n.get('width', 768)), height=int(n.get('height', 1376)),
        ref_size=int(n.get('ref_max_size', 1376))), ensure_ascii=False, separators=(',', ':'))
    assert 'reference.mp4' not in n['timeline_data']
    if old.get('version', 0) not in (0, 5):
        raise BatchError(f'Неожиданная версия timeline_data: {old.get("version")}')
    result['7']['inputs']['filename_prefix'] = f'MiniMaxH3Batch/{run_id}/{reel_id}'
    return result


def sanitize_against_object_info(api, object_info):
    """Drop unrecognized widget keys; preflight for installed custom nodes.

    Unknown inputs are not valid on all ComfyUI versions. Schema is authoritative
    for this running installation. For empty object_info skip filtering.
    """
    for id_, n in api.items():
        schema = object_info.get(n['class_type'])
        if not schema:
            raise BatchError(f'В ComfyUI не установлена нода {n["class_type"]} (ID {id_})')
        formal = schema.get('input') or {}
        allowed = set((formal.get('required') or {}).keys()) | set((formal.get('optional') or {}).keys()) | set((formal.get('hidden') or {}).keys())
        if allowed:
            for key in list(n['inputs']):
                if key not in allowed:
                    del n['inputs'][key]
            required = set((formal.get('required') or {}).keys())
            missing = required - set(n['inputs'])
            if missing:
                raise BatchError(f'Нода {id_} ({n["class_type"]}) требует входы {sorted(missing)}; несовместимая версия?')
    h3 = api['5']['inputs']
    for name in ('timeline_data', 'task_type', 'seed', 'total_frames', 'global_prompt'):
        if name not in h3:
            raise BatchError(f'MiniMaxH3Director не содержит {name} — версия плагина изменилась')
    return api


def request_json(base, path, payload=None, timeout=30):
    if not re.fullmatch(r'https?://[^/?#\s]+(?:/[^?#\s]*)?', base):
        raise BatchError('Некорректный URL ComfyUI')
    req = urllib.request.Request(base.rstrip('/') + path,
        data=json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None,
        headers={'Content-Type': 'application/json'} if payload is not None else {},
        method='POST' if payload is not None else 'GET')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as e:
        text=e.read().decode('utf-8',errors='replace')[:5000]
        raise BatchError(f'ComfyUI HTTP {e.code}: {text}') from e
    except (urllib.error.URLError, TimeoutError) as e:
        raise BatchError(f'ComfyUI недоступен {base}: {e}') from e


def get_remote_image(base, info):
    args={'filename': info['filename'], 'subfolder': info.get('subfolder',''), 'type': info.get('type','output')}
    url=base.rstrip('/')+'/view?'+urllib.parse.urlencode(args)
    try:
        with urllib.request.urlopen(url, timeout=90) as response:
            data = response.read(MAX_IMAGE_BYTES + 1)
    except urllib.error.HTTPError as e:
        raise BatchError(f'Фото {info["filename"]} не найдено на ComfyUI: {e}') from e
    if len(data)>MAX_IMAGE_BYTES:
        raise BatchError('Файл изображения слишком большой (>60 MB)')
    return data, Path(info['filename']).suffix.lower()


def multipart_upload(base, data, destination_name, suffix):
    boundary='---H3Batch'+uuid.uuid4().hex
    safe_basename=Path(destination_name).name
    content_type=mimetypes.guess_type('image'+suffix)[0] or 'application/octet-stream'
    def field(name, value):
        return (f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8')
    body=field('type','input')+field('overwrite','false')
    body+=(f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{safe_basename}"\r\nContent-Type: {content_type}\r\n\r\n').encode('utf-8') + data + b'\r\n'
    body+=(f'--{boundary}--\r\n').encode('utf-8')
    req=urllib.request.Request(base.rstrip('/')+'/upload/image', data=body,
        headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})
    try:
        with urllib.request.urlopen(req, timeout=120) as response:
            result = json.load(response)
    except urllib.error.HTTPError as e:
        raise BatchError('Ошибка загрузки фото в ComfyUI: '+e.read().decode(errors='replace')[:1200]) from e
    if not result.get('name'):
        raise BatchError('ComfyUI /upload/image не вернул имя загруженного файла')
    if result.get('subfolder',''):
        raise BatchError('ComfyUI сохранил загруженное фото в подпапку неожиданно; ожидается input root')
    return result['name']


def upload_image(base, pair, run_id):
    file_path=pair.get('photo_path')
    if file_path:
        p=Path(file_path)
        if p.stat().st_size>MAX_IMAGE_BYTES:
            raise BatchError(f'Слишком большой файл {p} (>60 MB)')
        data=p.read_bytes(); suffix=p.suffix.lower()
    else:
        data, suffix = get_remote_image(base, pair['remote_image'])
    if suffix not in INPUT_EXT:
        raise BatchError(f'Неподдерживаемый формат: {suffix}')
    # UUID prevents overwriting other batches or existing ComfyUI images.
    fname=f'H3B_{run_id}_{pair["id"]}_{uuid.uuid4().hex[:8]}{suffix}'
    return multipart_upload(base, data, fname, suffix)


def ledger_write(path, info):
    path=Path(path)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def queue_batch(base, ui_workflow_path, paired, *, seconds=15, limit=0,
                emit=None, stop_event=None, run_id=None, dry_run=False):
    emit=emit or (lambda msg: print(msg,flush=True))
    stop_event=stop_event or threading.Event()
    run_id=run_id or datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]
    wf = read_json(ui_workflow_path)
    api = convert_ui_to_api(wf)
    if not paired:
        raise BatchError('Нет совпадающих фото и видеопромптов')
    jobs=paired[:limit] if limit else paired
    run_folder=HERE/'runs'/run_id
    run_folder.mkdir(parents=True,exist_ok=True)
    output_log=run_folder/'h3_manifest.json'
    ledger={'run_id':run_id, 'comfyui_url':base, 'duration_seconds':seconds,
            'total':len(jobs), 'status':'preparing', 'items':[]}
    ledger_write(output_log, ledger)
    for item in jobs:
        ledger['items'].append({'id':item['id'], 'source':item.get('photo_path') or item.get('remote_image'),
                                'video_prompt':item['video_prompt'], 'status':'pending'})
    ledger_write(output_log, ledger)
    if dry_run:
        for index,item in enumerate(jobs):
            example=prepare_job(api,item['video_prompt'],f'SAMPLE_{item["id"]}.png',item['id'],run_id,seconds)
            tl=json.loads(example['5']['inputs']['timeline_data'])
            if tl['segments'][0]['prompt']!=item['video_prompt'] or len(tl['segments'][0]['refs']) != 1:
                raise BatchError('Не удалось правильно вставить промпт/фото')
            ledger['items'][index]['status']='validated'
            emit(f"OK {item['id']} ← {Path(item.get('photo_path') or 'ComfyUI output').name}")
        ledger['status']='validated'
        ledger_write(output_log,ledger)
        emit('Проверка завершена — ничего не отправлено в ComfyUI.')
        return ledger
    emit('Проверяю установленные ноды ComfyUI...')
    object_info=request_json(base,'/object_info',timeout=30)
    sanitize_against_object_info(api,object_info)
    # Store a generated debug API example with fake filename to aid troubleshooting.
    example=prepare_job(api,jobs[0]['video_prompt'],'FIRST_FRAME_PLACEHOLDER.png',jobs[0]['id'],run_id,seconds)
    (run_folder/'example_api_debug.json').write_text(json.dumps(example,ensure_ascii=False,indent=2),encoding='utf-8')
    ledger['status']='queuing'
    ledger_write(output_log,ledger)
    for ix,item in enumerate(jobs):
        if stop_event.is_set():
            ledger['status']='stopped';ledger_write(output_log,ledger)
            emit('Остановлена отправка новых задач. Уже поставленные задачи остались в ComfyUI.')
            break
        row=ledger['items'][ix]
        try:
            image_name=upload_image(base,item,run_id)
            prompt=prepare_job(api,item['video_prompt'],image_name,item['id'],run_id,seconds)
            metadata={'h3_batch':{'run_id':run_id,'id':item['id'],
                                  'source_filename':Path(item.get('photo_path') or item['remote_image']['filename']).name}}
            resp=request_json(base,'/prompt',{'prompt': prompt, 'client_id': 'H3BatchStudio-'+run_id,
                       'extra_data': {'extra_pnginfo': metadata}}, timeout=120)
            if not resp.get('prompt_id'):
                raise BatchError(f'ComfyUI не принял {item["id"]}: {json.dumps(resp,ensure_ascii=False)[:1800]}')
            row.update(status='queued',uploaded_file=image_name, prompt_id=resp['prompt_id'],
                       output_prefix=prompt['7']['inputs']['filename_prefix'],seed=prompt['5']['inputs']['seed'])
            emit(f"[{ix+1}/{len(jobs)}] QUEUED {item['id']} → {row['output_prefix']}")
        except Exception as e:
            row.update(status='error',error=str(e))
            ledger['status']='error';ledger_write(output_log,ledger)
            emit(f'ОШИБКА {item["id"]}: {e}')
            emit('Остановка при первой ошибке, чтобы не ставить 50 неверных задач.')
            raise
        ledger_write(output_log,ledger)
    else:
        ledger['status']='queued'
        ledger_write(output_log,ledger)
        emit(f'Готово: поставлено в очередь {len(jobs)} заданий. Видео сохранятся в ComfyUI/output/MiniMaxH3Batch/{run_id}/')
    return ledger
