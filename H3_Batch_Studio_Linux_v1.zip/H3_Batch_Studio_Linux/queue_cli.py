"""Non-GUI alternative, e.g. python queue_cli.py --photos ... --catalog ... --one."""
import argparse
import sys
from batch_core import HERE, BatchError, read_catalog, pair_items, queue_batch

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--photos',default=str(HERE/'photos'),help='Folder with NR001_00001_.png etc; may be empty with --remote')
    p.add_argument('--catalog',default=str(HERE/'catalogs'/'miami_50_scenarios.json'),help='Qwen catalog or Qwen run manifest.json')
    p.add_argument('--workflow',default=str(HERE/'h3_ui_template.json'))
    p.add_argument('--url',default='http://127.0.0.1:8188')
    p.add_argument('--seconds',type=int,default=15)
    p.add_argument('--one',action='store_true',help='Queue first matching video only')
    p.add_argument('--remote',action='store_true',help='Fallback to /view of Qwen images in manifest')
    p.add_argument('--skip-missing',action='store_true')
    p.add_argument('--dry-run',action='store_true')
    args=p.parse_args()
    _,items=read_catalog(args.catalog)
    paired,missing,duplicates=pair_items(items,args.photos,allow_remote=args.remote)
    print('Photos matched:',len(paired),'missing:',len(missing),'multiple versions:',len(duplicates))
    if missing and not args.skip_missing and not args.one:
        raise BatchError(f'Missing {len(missing)} IDs: {", ".join(missing[:20])}')
    if not paired:raise BatchError('No matching photos')
    queue_batch(args.url,args.workflow,paired,seconds=args.seconds,limit=1 if args.one else 0,dry_run=args.dry_run)

if __name__=='__main__':
    try:main()
    except (BatchError,FileNotFoundError,ValueError) as e:print('ERROR:',e,file=sys.stderr);sys.exit(1)
