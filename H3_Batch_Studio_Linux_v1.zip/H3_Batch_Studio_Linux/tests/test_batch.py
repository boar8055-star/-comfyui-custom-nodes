import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from batch_core import (convert_ui_to_api, prepare_job, read_catalog, pair_items,
                        create_clean_timeline, sanitize_against_object_info,
                        duration_frames, BatchError, HERE)


class TestBatch(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.workflow=json.loads((HERE/'h3_ui_template.json').read_text(encoding='utf-8'))
        cls.api=convert_ui_to_api(cls.workflow)

    def test_api_conversion(self):
        api=self.api
        self.assertEqual(api['5']['class_type'],'MiniMaxH3Director')
        self.assertEqual(api['7']['inputs']['video'],['6',0])
        self.assertEqual(api['5']['inputs']['model'],['14',0])
        self.assertEqual(api['14']['inputs']['model'],['1',0])
        self.assertEqual(api['12']['inputs']['images'],['5',0])
        self.assertEqual(api['12']['inputs']['source_fps'],['5',2])
        self.assertEqual(api['13']['inputs']['image'],['12',0])
        self.assertEqual(api['6']['inputs']['images'],['13',0])
        self.assertEqual(api['13']['inputs']['width'],1080)
        self.assertEqual(api['13']['inputs']['height'],1920)
        self.assertEqual(api['12']['inputs']['target_fps'],30)
        self.assertEqual(api['5']['inputs']['steps'],20)

    def test_clean_timeline_separate_per_item(self):
        a=prepare_job(self.api,'Miami film sample prompt for MIA001','H3B_demo_MIA001.png','MIA001','testdemo',15,seed=111)
        b=prepare_job(self.api,'Another prompt for NR055','H3B_demo_NR055.png','NR055','testdemo',10,seed=222)
        ta=json.loads(a['5']['inputs']['timeline_data'])
        tb=json.loads(b['5']['inputs']['timeline_data'])
        self.assertEqual(ta['segments'][0]['prompt'],'Miami film sample prompt for MIA001')
        self.assertEqual(ta['batchWorkspaces']['r2v']['segments'][0]['prompt'],'Miami film sample prompt for MIA001')
        self.assertEqual(ta['segments'][0]['refs'][0]['imageFile'],'H3B_demo_MIA001.png')
        self.assertEqual(ta['segments'][0]['refs'][0]['index'],0)
        self.assertEqual(len(ta['segments'][0]['refs']),1)
        self.assertEqual(ta['segments'][0]['refVideos'],[])
        self.assertNotIn('reference.mp4',json.dumps(a,ensure_ascii=False))
        self.assertNotIn('Trout on a Sunlit Fjord Rock.png',json.dumps(a,ensure_ascii=False))
        self.assertNotIn('neon-lit alley',json.dumps(a,ensure_ascii=False))
        self.assertNotIn('Another prompt',json.dumps(a,ensure_ascii=False))
        self.assertEqual(a['5']['inputs']['global_prompt'],'')
        self.assertEqual(a['7']['inputs']['filename_prefix'],'MiniMaxH3Batch/testdemo/MIA001')
        self.assertEqual(b['7']['inputs']['filename_prefix'],'MiniMaxH3Batch/testdemo/NR055')
        self.assertEqual(tb['segments'][0]['refs'][0]['imageFile'],'H3B_demo_NR055.png')
        self.assertEqual(ta['segments'][0]['length'],361)
        self.assertEqual(tb['segments'][0]['length'],241)
        self.assertEqual(self.api['5']['inputs']['seed'],1013980930568774)

    def test_pairing(self):
        catalog,items=read_catalog(HERE/'catalogs'/'miami_50_scenarios.json')
        self.assertEqual(len(items),50)
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)
            (p/'MIA001_00001_.png').write_bytes(b'old')
            (p/'MIA002_00001_.png').write_bytes(b'new')
            (p/'MIA0010_00001_.png').write_bytes(b'not a collision')
            paired,missing,warnings=pair_items(items,p)
            self.assertEqual([x['id'] for x in paired],['MIA001','MIA002'])
            self.assertEqual(len(missing),48)
            self.assertEqual(len(warnings),0)

    def test_no_fake_refilenames(self):
        data,items=read_catalog(HERE/'catalogs'/'norway_50_scenarios_v2.json')
        self.assertEqual(len(items),50)
        self.assertEqual(items[0]['id'],'NR051')
        self.assertEqual(items[-1]['id'],'NR100')
        self.assertTrue(all(x['video_prompt'] for x in items))

    def test_object_info_filters_dynamic_widgets(self):
        api=copy.deepcopy(self.api)
        info={}
        for n in api.values():
            keys=set(n['inputs'])
            # Simulate unknown UI-only property in SaveVideo.
            if n['class_type']=='SaveVideo':keys.discard('format.codec')
            info[n['class_type']]={'input':{'required':{k:['STRING',{}] for k in keys}}}
        cleaned=sanitize_against_object_info(api,info)
        self.assertNotIn('format.codec',cleaned['7']['inputs'])
        self.assertIn('timeline_data',cleaned['5']['inputs'])


if __name__=='__main__':unittest.main()

class TestMockComfyIntegration(unittest.TestCase):
    def test_upload_and_prompt_queue(self):
        import http.server, threading, tempfile
        import batch_core
        from batch_core import queue_batch
        src=read_json(HERE/'h3_ui_template.json') if False else None
        api=convert_ui_to_api(json.loads((HERE/'h3_ui_template.json').read_text(encoding='utf8')))
        info={}
        for n in api.values():
            keys=set(n['inputs'])
            info[n['class_type']]={'input':{'required':{k:['STRING',{}] for k in keys}}}
        requests_seen=[]
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path!='/object_info':self.send_error(404);return
                data=json.dumps(info).encode('utf8')
                self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
            def do_POST(self):
                length=int(self.headers.get('Content-Length','0'))
                payload=self.rfile.read(length)
                if self.path=='/upload/image':
                    self.assert_header=payload
                    # Extract generated uploaded name from multipart body for test.
                    import re
                    name=re.search(rb'filename="([^"]+)"',payload).group(1).decode()
                    requests_seen.append(('upload',name))
                    result={'name':name,'subfolder':'','type':'input'}
                elif self.path=='/prompt':
                    req=json.loads(payload)
                    requests_seen.append(('prompt',req))
                    result={'prompt_id':'prompt_mock_123','number':1,'node_errors':{}}
                else:self.send_error(404);return
                data=json.dumps(result).encode()
                self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
            def log_message(self,*args):pass
        server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
        t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
        original=batch_core.HERE
        try:
            with tempfile.TemporaryDirectory() as d:
                batch_core.HERE=Path(d)
                p=Path(d)/'MIA001_00001_.png';p.write_bytes(b'\x89PNG\r\nmock')
                pair={'id':'MIA001','video_prompt':'Smile by a Miami pool <Picture 1>',
                      'photo_path':str(p),'remote_image':None}
                ledger=queue_batch(f'http://127.0.0.1:{server.server_port}',
                    HERE/'h3_ui_template.json',[pair],run_id='integration_test',seconds=15)
                self.assertEqual(ledger['status'],'queued')
                self.assertEqual(ledger['items'][0]['status'],'queued')
                self.assertEqual(len(requests_seen),2)
                req=requests_seen[1][1]
                tl=json.loads(req['prompt']['5']['inputs']['timeline_data'])
                self.assertEqual(tl['segments'][0]['refs'][0]['imageFile'],requests_seen[0][1])
                self.assertEqual(tl['segments'][0]['prompt'],pair['video_prompt'])
                self.assertEqual(req['prompt']['7']['inputs']['filename_prefix'],'MiniMaxH3Batch/integration_test/MIA001')
                self.assertEqual(req['prompt']['5']['inputs']['total_frames'],361)
                self.assertEqual(req['prompt']['14']['inputs']['sage_attention'],'auto')
                self.assertNotIn('neon-lit alley',json.dumps(req))
        finally:
            batch_core.HERE=original
            server.shutdown();server.server_close()
