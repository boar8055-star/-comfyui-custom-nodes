#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
# localhost by default; set H3_STUDIO_TOKEN before binding 0.0.0.0
exec python3 web_app.py --host "${H3_STUDIO_HOST:-127.0.0.1}" --port "${H3_STUDIO_PORT:-8766}"
