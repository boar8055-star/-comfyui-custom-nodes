# MiniMax H3 Batch Studio — Linux `/workspace/ComfyUI`

Это **Linux-вариант** прежнего Windows-пакета. ComfyUI с MiniMax H3 находится на Linux (например Vast.ai) в `/workspace/ComfyUI`, а фотографии Qwen можно сделать на Windows и перенести сюда. Библиотеки **не устанавливаются**: Python 3.10+ и стандартные модули.

## Быстрый запуск через терминал Linux

```bash
cd /workspace
unzip -o H3_Batch_Studio_Linux_v1.zip
cd H3_Batch_Studio_Linux
bash START_LINUX.sh
```

Сервер Batch Studio по умолчанию запустится на `127.0.0.1:8766`, ComfyUI должен работать на `127.0.0.1:8188` (поменяй URL в форме, если H3 использует другой порт).

Для открытия веб-интерфейса с собственного компьютера можно использовать SSH-переадресацию (подставь хост и порт своего SSH):

```bash
ssh -L 8766:127.0.0.1:8766 -p <SSH_PORT> root@<SSH_HOST>
```

Потом открываешь в браузере Windows `http://127.0.0.1:8766`.

Если используешь публичный порт контейнера через Vast.ai, можно запустить так:

```bash
export H3_STUDIO_TOKEN='придумай_длинный_случайный_токен'
H3_STUDIO_HOST=0.0.0.0 bash START_LINUX.sh
```

**Не оставляй публичный порт без токена**; HTTP-токен не заменяет HTTPS, поэтому лучше SSH-туннель.

## Как перенести фотографии Windows → Linux

Самый простой способ — заархивировать на Windows папку с PNG в ZIP и загрузить файл через кнопку «Загрузить ZIP на Linux» в веб-интерфейсе. Она создаст Linux-папку `photos/import_.../` и сама подставит путь. Можно и просто положить фотографии в `/workspace/H3_Batch_Studio_Linux/photos/` через SSH/SFTP.

Каталоги из первых пачек уже включены в `catalogs`: Miami 50, Norway 1 и Norway 2. Другой каталог или Qwen `manifest.json` можно импортировать кнопкой «Загрузить JSON-каталог на Linux».

Для 50 рилсов должны совпадать ID имён файлов и поле `id` каталога. Например `MIA001_00001_.png` совпадёт с `"id":"MIA001"`, а `NR051_00001_.png` — с `"id":"NR051"`. Если фото нет, оно пропускается при включенной настройке «Пропускать сценарии без PNG».

## Работа

1. Запусти ComfyUI c рабочей моделью MiniMax H3.
2. Открой Batch Studio (веб-интерфейс либо CLI).
3. Передай ZIP фотографий или укажи папку на Linux.
4. Выбери каталог с `video_prompt`.
5. Нажми **Проверить пары**, затем **QUEUE 1 VIDEO**.
6. После успешного теста нажми **QUEUE ALL VIDEOS**. **Внимание:** 1 ролик, который был поставлен на тест, повторно появится в очереди при QUEUE ALL (если файл остался в папке).

Программа загружает каждую PNG в `ComfyUI/input` через `/upload/image`, подставляет её как `<Picture 1>` в `MiniMaxH3Director`, подставляет соответствующий `video_prompt` в timeline, удаляет старые ссылки на другие фотографии, видео, аудио, сохраняет твои настройки SageAttention, 20 steps, RIFE 24→30 FPS и финальный upscale 1080×1920.

**Результаты:** `/workspace/ComfyUI/output/MiniMaxH3Batch/<run_id>/`. Отчёт с ComfyUI `prompt_id`, фотографиями и промптами: `runs/<run_id>/h3_manifest.json` внутри Batch Studio. Отправка в очередь ≠ готовый рендер.

## Если нужна работа БЕЗ веб-интерфейса (CLI)

Проверка пар, без обращения к ComfyUI:

```bash
cd /workspace/H3_Batch_Studio_Linux
python3 queue_cli.py --photos /workspace/H3_Batch_Studio_Linux/photos --catalog catalogs/miami_50_scenarios.json --dry-run
```

Поставить **одно** видео на Linux ComfyUI:

```bash
python3 queue_cli.py --photos /workspace/H3_Batch_Studio_Linux/photos --catalog catalogs/miami_50_scenarios.json --url http://127.0.0.1:8188 --one
```

Поставить все пары:

```bash
python3 queue_cli.py --photos /workspace/H3_Batch_Studio_Linux/photos --catalog catalogs/miami_50_scenarios.json --url http://127.0.0.1:8188 --skip-missing
```

## Важно про текущий workflow и режимы

Шаблон `h3_ui_template.json` создан из твоего `sageattention.json`: там **r2v/ref2va**. В этом автоматическом пакете используется **один** PNG для `<Picture 1>`, а не три отдельных изображения + исходное `<Video 1>`. Эта версия предназначена для создания нового видео из готового первого кадра Qwen и соответствующего видеопромпта. Она **не** является автоматическим vid-to-vid faceswap/body replacement по трём картинкам и исходному видео. Для этой задачи нужен другой batch workflow (со всеми четырьмя настоящими референсами).

Оригинальный `sageattention.json` содержал старое, не относящееся к текущим роликам содержимое в timeline. Оно полностью сброшено в пакетном шаблоне, чтобы не смешивать сцены. Граф проходит локальные автоматические тесты, но **рендер в твоём Linux ComfyUI не выполнялся** — сначала запусти одно задание.

При другой версии AIMixer MiniMaxH3Director API может отличаться: программа проверяет `/object_info`, а при несовместимости выводит ошибку, не заполняя очередь ошибочными задачами.
