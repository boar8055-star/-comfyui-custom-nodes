"""H3 multi-GPU stage-barrier batch panel for one Vast.ai container.

Starts one persistent ComfyUI request worker per online endpoint; reuses the
same process on every item of a stage, then synchronizes before next stage.
"""
import copy
import json
import os
import queue
import re
import shutil
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

import requests
from flask import Flask, Response, jsonify, render_template, request
from pipeline import make_graph

app = Flask(__name__)
HOME = Path(os.environ.get('H3_BATCH_HOME', '/workspace/h3_batch')).resolve()
HOME.mkdir(parents=True, exist_ok=True)
ROOTS = [Path(x.strip()).resolve() for x in os.environ.get('H3_ALLOWED_ROOTS', '/workspace').split(',') if x.strip()]
COMFY = [f'http://127.0.0.1:{p.strip()}' for p in os.environ.get('H3_COMFY_PORTS', '8188,8189,8190,8191').split(',') if p.strip()]
PASSWORD = os.environ.get('H3_PANEL_PASSWORD', '')
VIDEO_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.avi'}
IMAGE_EXT = {'.jpg', '.jpeg', '.png', '.webp'}
LOCK = threading.RLock()
ACTIVE = None
ABORT = threading.Event()
LAST_LOGS = []
SESSION = requests.Session()


def protected(path):
    p = Path(path).expanduser().resolve()
    if not any(p == root or root in p.parents for root in ROOTS):
        raise ValueError(f'Folder outside allowed roots: {p}')
    return p


def natural_key(path):
    return [int(s) if s.isdigit() else s.lower() for s in re.split(r'(\d+)', Path(path).name)]


def files_in(folder, exts):
    p = protected(folder)
    if not p.is_dir():
        raise ValueError('Folder does not exist: ' + str(p))
    return sorted((child for child in p.iterdir() if child.is_file() and child.suffix.lower() in exts), key=natural_key)


def now():
    return datetime.now().astimezone().isoformat(timespec='seconds')


def snap():
    with LOCK:
        return copy.deepcopy(ACTIVE)


def persist():
    # Keep the disk write under the SAME lock: four GPU threads otherwise
    # race to replace a shared .tmp file, occasionally losing state updates.
    with LOCK:
        if ACTIVE is None:
            return
        save = copy.deepcopy(ACTIVE)
        p = HOME / 'runs' / save['id'] / 'state.json'
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(save, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, p)


def update_task(run_id, index, stage, status, gpu=None, error=None):
    with LOCK:
        if not ACTIVE or ACTIVE['id'] != run_id:
            return
        current = ACTIVE['tasks'][index]['stages'][str(stage)]
        current.update({'status': status, 'gpu': gpu, 'updated': now()})
        if error is not None:
            current['error'] = str(error)[-1700:]
        elif status == 'done':
            current['error'] = ''
    persist()


def update_run(run_id, **kwargs):
    with LOCK:
        if ACTIVE and ACTIVE['id'] == run_id:
            ACTIVE.update(kwargs)
    persist()


def ask(session, method, url, *, timeout=10, **kwargs):
    result = session.request(method, url, timeout=timeout, **kwargs)
    result.raise_for_status()
    return result.json()


def check_worker(port):
    try:
        stats = ask(SESSION, 'GET', f'{port}/system_stats', timeout=2)
        return {'url': port, 'online': True, 'devices': stats.get('devices', [])}
    except (requests.RequestException, ValueError):
        return {'url': port, 'online': False, 'devices': []}


def wait_idle(session, port, abort, seconds=1800):
    until = time.monotonic() + seconds
    while not abort.is_set():
        if time.monotonic() >= until:
            raise TimeoutError(f'GPU worker {port} is busy too long')
        q = ask(session, 'GET', f'{port}/queue', timeout=8)
        if not q.get('queue_running') and not q.get('queue_pending'):
            return
        time.sleep(2)
    raise RuntimeError('Batch stop requested')


def execute(session, port, graph, path, abort, stage):
    # Calls are issued only to an idle ComfyUI instance, not queued behind
    # unrelated tasks. Exactly one job per worker process at any moment.
    wait_idle(session, port, abort)
    response = ask(session, 'POST', f'{port}/prompt', timeout=60,
                   json={'prompt': graph, 'client_id': 'h3batch-' + uuid.uuid4().hex})
    prompt_id = response.get('prompt_id')
    if not prompt_id:
        raise RuntimeError(f'ComfyUI rejected graph: {response}')
    started = time.monotonic()
    timeout_seconds = int(os.environ.get('H3_JOB_TIMEOUT', '7200'))
    while time.monotonic() - started < timeout_seconds:
        # Let a submitted graph finish even after a soft stop; avoids corrupt
        # intermediate files and leaves already-running Comfy workflows intact.
        result = ask(session, 'GET', f'{port}/history/{prompt_id}', timeout=15)
        record = result.get(prompt_id)
        if record:
            status = record.get('status', {})
            if status.get('status_str') == 'error' or status.get('completed') is False:
                messages = status.get('messages', [])
                raise RuntimeError(f'Stage {stage} failed: {json.dumps(messages, ensure_ascii=False)[-1800:]}')
            if status.get('completed') or status.get('status_str') == 'success':
                if path.exists() and path.stat().st_size > 1000:
                    return
                raise RuntimeError('Comfy marked job complete, but output file is absent: ' + str(path))
        time.sleep(2)
    raise TimeoutError(f'ComfyUI job {prompt_id} exceeded {timeout_seconds}s on {port}')


def run_one(session, port, stage, item, lossless, stop):
    p1, p2, final = [Path(item[key]) for key in ('stage1', 'stage2', 'final')]
    target = {1:p1, 2:p2}[stage]
    if target.is_file() and target.stat().st_size > 1000:
        return 'existing'
    graph = make_graph(stage,
                       original_video=item['video'], body=item['body'],
                       stage1_path=p1, stage2_path=p2, final_path=final,
                       face_front=item['face_front'], face_side=item['face_side'],
                       lossless=lossless)
    execute(session, port, graph, target, stop, stage)
    return 'new'


def stage_workers(run_id, stage, online, indices, lossless):
    tasks = queue.Queue()
    for i in indices:
        tasks.put(i)
    offline = set()
    offline_lock = threading.Lock()

    def worker(gpu_index, port):
        with requests.Session() as s:
            while not ABORT.is_set():
                try:
                    i = tasks.get_nowait()
                except queue.Empty:
                    break
                with LOCK:
                    item = copy.deepcopy(ACTIVE['tasks'][i])
                update_task(run_id, i, stage, 'running', gpu=gpu_index)
                try:
                    run_one(s, port, stage, item, lossless, ABORT)
                    update_task(run_id, i, stage, 'done', gpu=gpu_index)
                except requests.RequestException as exc:
                    with offline_lock:
                        offline.add(gpu_index)
                    # Another worker may pick it up. If all GPUs die, the
                    # parent marks leftover work as failed.
                    update_task(run_id, i, stage, 'pending', gpu=None, error=f'worker offline: {exc}')
                    tasks.put(i)
                    break
                except Exception as exc:
                    update_task(run_id, i, stage, 'failed', gpu=gpu_index, error=exc)
                finally:
                    tasks.task_done()

    threads = [threading.Thread(target=worker, args=(gpu, url), daemon=True)
               for gpu, url in online]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    while True:
        try:
            i = tasks.get_nowait()
            status = 'skipped' if ABORT.is_set() else 'failed'
            update_task(run_id, i, stage, status, error='Stopped / all GPU workers unavailable')
            tasks.task_done()
        except queue.Empty:
            break
    return offline


def work(run_id):
    try:
        with LOCK:
            selected = ACTIVE['selected_gpus']
            lossless = ACTIVE['lossless']
        online = [(i+1, COMFY[i]) for i in selected if i < len(COMFY) and check_worker(COMFY[i])['online']]
        if not online:
            raise RuntimeError('None of the selected ComfyUI endpoints are running')
        update_run(run_id, status='running', gpus=[p[0] for p in online])
        for stage in (1, 2):
            if ABORT.is_set():
                break
            update_run(run_id, stage=stage)
            with LOCK:
                items = copy.deepcopy(ACTIVE['tasks'])
            indices = []
            for i, task in enumerate(items):
                if stage > 1 and task['stages'][str(stage-1)]['status'] != 'done':
                    update_task(run_id, i, stage, 'skipped', error=f'Previous stage {stage-1} did not succeed')
                else:
                    indices.append(i)
            if indices:
                offline = stage_workers(run_id, stage, online, indices, lossless)
                online = [entry for entry in online if entry[0] not in offline]
            if ABORT.is_set():
                break
            # Deliberately unload only ONCE PER STAGE, never between videos.
            if stage < 2:
                for gpu, port in online:
                    try:
                        requests.post(port + '/free', json={'unload_models': True, 'free_memory': True}, timeout=5)
                    except requests.RequestException:
                        pass
        with LOCK:
            tasks = copy.deepcopy(ACTIVE['tasks'])
        failed = sum(1 for t in tasks if any(s['status'] == 'failed' for s in t['stages'].values()))
        update_run(run_id, status=('stopped' if ABORT.is_set() else 'finished'),
                   finished=now(), failed=failed)
    except Exception as exc:
        update_run(run_id, status='error', error=str(exc), finished=now())


@app.before_request
def auth():
    if not PASSWORD:
        return None
    credentials = request.authorization
    if not credentials or not credentials.password or credentials.password != PASSWORD:
        return Response('H3 Batch: password required', 401,
                        {'WWW-Authenticate': 'Basic realm="H3 Batch"'})
    return None


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/api/config')
def config():
    return jsonify({'roots': list(map(str, ROOTS)), 'home': str(HOME),
                    'comfy': [check_worker(port) for port in COMFY]})


@app.get('/api/browse')
def browse():
    try:
        path = protected(request.args.get('path') or str(ROOTS[0]))
        if not path.is_dir():
            raise ValueError('Not a directory')
        dirs = sorted((c for c in path.iterdir() if c.is_dir() and not c.name.startswith('.')),
                      key=natural_key)
        video_count = len(files_in(path, VIDEO_EXT))
        image_count = len(files_in(path, IMAGE_EXT))
        parent = str(path.parent) if any(path != r and r in path.parents for r in ROOTS) else None
        return jsonify({'path': str(path), 'parent': parent,
                        'dirs': [{'name': d.name, 'path': str(d)} for d in dirs],
                        'video_count': video_count, 'image_count': image_count,
                        'files': [{'name': f.name, 'path': str(f)} for f in files_in(path, IMAGE_EXT)[:200]]})
    except (ValueError, OSError) as exc:
        return jsonify({'error': str(exc)}), 400


@app.post('/api/start')
def start():
    global ACTIVE
    payload = request.get_json(force=True)
    try:
        sources = files_in(payload.get('videos', ''), VIDEO_EXT)
        bodies = files_in(payload.get('bodies', ''), IMAGE_EXT)
        if not sources or not bodies:
            raise ValueError('Both folders need at least one matching file')
        if len(sources) > 10000:
            raise ValueError('Too many videos in one run')
        selected = [int(v)-1 for v in payload.get('gpus', [1,2,3,4])]
        if not selected or any(i < 0 or i >= len(COMFY) for i in selected):
            raise ValueError('Select available GPU1–GPU4')
        selected = sorted(set(selected))
        face_front = payload.get('face_front', '').strip()
        face_side = payload.get('face_side', '').strip()
        for face in (face_front, face_side):
            if face and (not protected(face).is_file() or Path(face).suffix.lower() not in IMAGE_EXT):
                raise ValueError('Face reference is not an image: ' + face)
        with LOCK:
            if ACTIVE and ACTIVE['status'] in ('starting','running'):
                raise ValueError('There is already an active batch')
            ABORT.clear()
            run_id = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
            run_dir = HOME / 'runs' / run_id
            tasks = []
            for n, video in enumerate(sources):
                body = bodies[n % len(bodies)]
                stem = f'{n+1:04d}_{re.sub(r"[^A-Za-z0-9_-]", "_", video.stem)[:48]}'
                tasks.append({'video': str(video), 'body': str(body),
                              'face_front': str(protected(face_front)) if face_front else str(body),
                              'face_side': str(protected(face_side)) if face_side else str(body),
                              'stage1': str(run_dir / 'stage1' / (stem + '.mkv')),
                              'stage2': str(run_dir / 'FINAL_H3_24FPS' / (stem + '.mkv')),
                              'final': str(run_dir / 'FINAL_H3_24FPS' / (stem + '.mkv')),
                              'stages': {str(i): {'status': 'pending', 'gpu': None, 'updated': None, 'error': ''}
                                         for i in (1,2)}})
            ACTIVE = {'id': run_id, 'status': 'starting', 'created': now(), 'finished': None,
                      'stage': 0, 'videos_dir': str(sources[0].parent), 'bodies_dir': str(bodies[0].parent),
                      'lossless': bool(payload.get('lossless', False)), 'selected_gpus': selected,
                      'gpus': [], 'tasks': tasks, 'error': ''}
        persist()
        threading.Thread(target=work, args=(run_id,), daemon=True).start()
        return jsonify({'ok': True, 'run_id': run_id, 'total': len(sources)})
    except (ValueError, KeyError, OSError) as exc:
        return jsonify({'error': str(exc)}), 400


@app.get('/api/status')
def status():
    return jsonify({'run': snap()})


@app.post('/api/stop')
def stop():
    ABORT.set()
    return jsonify({'ok': True, 'message': 'Current GPU tasks finish; pending ones are skipped'})


@app.get('/api/disk')
def disk():
    data = shutil.disk_usage(HOME)
    return jsonify({'total_gb': round(data.total/1e9, 1), 'free_gb': round(data.free/1e9, 1)})


if __name__ == '__main__':
    app.run(host=os.environ.get('H3_PANEL_HOST', '127.0.0.1'),
            port=int(os.environ.get('H3_PANEL_PORT','18766')), threaded=True)
