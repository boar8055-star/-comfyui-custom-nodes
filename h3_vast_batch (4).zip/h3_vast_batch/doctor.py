#!/usr/bin/env python3
"""Check API-worker readiness and missing ComfyUI node packs without running GPU jobs."""
import os
from pathlib import Path
import requests
from pipeline import make_graph

ports = [p.strip() for p in os.environ.get('H3_COMFY_PORTS', '8188,8189,8190,8191').split(',') if p.strip()]
dummy = dict(original_video='/workspace/source/test.mp4', body='/workspace/body/one.png',
             stage1_path='/workspace/h3_batch/a.mkv',stage2_path='/workspace/h3_batch/b.mkv',
             final_path='/workspace/h3_batch/f.mp4')
expected = set()
for i in (1,2):
    expected.update(n['class_type'] for n in make_graph(i, **dummy).values())

passed = 0
for i, port in enumerate(ports, 1):
    base=f'http://127.0.0.1:{port}'
    print(f'\nGPU{i} {base}')
    try:
        stat=requests.get(base+'/system_stats',timeout=5);stat.raise_for_status()
        devices=stat.json().get('devices',[])
        for dev in devices:
            print('  Device:', dev.get('name'), 'VRAM:', round(dev.get('vram_total',0)/2**30,1),'GiB')
        obj=requests.get(base+'/object_info',timeout=40);obj.raise_for_status()
        offered=set(obj.json())
        missing=sorted(expected-offered)
        if missing:
            print('  MISSING:', ', '.join(missing))
        else:
            print('  All',len(expected),'required node types are registered')
            passed+=1
    except Exception as exc:
        print('  OFFLINE / ERROR:',exc)
print(f'\nReady ComfyUI workers: {passed}/{len(ports)}')
raise SystemExit(0 if passed else 1)
