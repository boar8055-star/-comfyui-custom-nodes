#!/usr/bin/env bash
set -euo pipefail

COMFY="${1:-/workspace/ComfyUI}"
PY="${2:-/venv/main/bin/python}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$COMFY/custom_nodes" ]]; then
  echo "[ERROR] ComfyUI custom_nodes folder not found: $COMFY/custom_nodes" >&2
  exit 2
fi
if [[ ! -x "$PY" ]]; then
  echo "[ERROR] ComfyUI Python not found: $PY" >&2
  exit 2
fi
if [[ ! -f "$SCRIPT_DIR/h3_text_overlay_recovery/__init__.py" ]]; then
  echo "[ERROR] Missing custom node files in $SCRIPT_DIR" >&2
  exit 2
fi

mkdir -p "$COMFY/custom_nodes/h3_text_overlay_recovery"
cp -f "$SCRIPT_DIR/h3_text_overlay_recovery/__init__.py" "$COMFY/custom_nodes/h3_text_overlay_recovery/__init__.py"
cp -f "$SCRIPT_DIR/h3_text_overlay_recovery/requirements.txt" "$COMFY/custom_nodes/h3_text_overlay_recovery/requirements.txt"

"$PY" -m pip install -r "$COMFY/custom_nodes/h3_text_overlay_recovery/requirements.txt"
"$PY" -c 'from rapidocr import RapidOCR; from cv2 import __version__ as v; print("RapidOCR ready; OpenCV", v)'

echo "[OK] Installed H3 text-overlay recovery to $COMFY/custom_nodes/h3_text_overlay_recovery"
echo "[NEXT] Restart ComfyUI workers when they are idle, then import the workflow JSON."
