"""Preserve overlaid captions from the source video after H3 character swaps.

ComfyUI custom node. On first run install dependencies from requirements.txt.
"""

import logging
import cv2
import numpy as np
import torch

_LOG = logging.getLogger("H3TextOverlay")


class H3RestoreOverlayText:
    """Find caption polygons on source frames, lift original glyph pixels over swapped frames.

    The OCR model is invoked on the *source*, never on the generated output.
    We use text detection only, not text recognition, to support Cyrillic and
    other languages without recognition-language dependencies.
    """

    _ocr = None

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "original_images": ("IMAGE",),
            "processed_images": ("IMAGE",),
            "enabled": ("BOOLEAN", {"default": True}),
            "text_mode": (["auto_glyphs", "light_text", "dark_text", "colored_text", "full_text_regions"], {"default": "auto_glyphs"}),
            "scan_every_n_frames": ("INT", {"default": 3, "min": 1, "max": 60, "step": 1}),
            "detection_confidence": ("FLOAT", {"default": 0.30, "min": 0.0, "max": 1.0, "step": 0.05}),
            "glyph_expand_px": ("INT", {"default": 2, "min": 0, "max": 12, "step": 1}),
            "text_box_padding_px": ("INT", {"default": 4, "min": 0, "max": 24, "step": 1}),
            "blend_strength": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.05}),
        }}

    RETURN_TYPES = ("IMAGE", "MASK", "STRING")
    RETURN_NAMES = ("restored_images", "restored_text_masks", "report")
    FUNCTION = "restore"
    CATEGORY = "H3 / Video Text Protection"
    DESCRIPTION = "Restores OCR-detected overlay text from the original video after both character replacement passes. Full_text_regions is a fallback that may re-introduce the original subject inside text boxes."

    @classmethod
    def _engine(cls):
        if cls._ocr is None:
            try:
                from rapidocr import RapidOCR
            except ImportError as e:
                raise RuntimeError(
                    "[H3 Text Recovery] Missing RapidOCR. Activate ComfyUI's Python environment "
                    "and run: python -m pip install rapidocr onnxruntime; then restart ComfyUI."
                ) from e
            # CPU ONNX: independent of the GPU MiniMax models; small PP-OCR models.
            cls._ocr = RapidOCR()
        return cls._ocr

    @staticmethod
    def _rgb8(t):
        rgb = t.detach().float().cpu().numpy()
        return np.uint8(np.clip(rgb * 255.0 + 0.5, 0, 255))

    @staticmethod
    def _detect(image_rgb, ocr, minimum_confidence):
        # RapidOCR 2+ supports detection-only, avoiding language-specific OCR.
        result = ocr(cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR), use_det=True, use_cls=False, use_rec=False)
        boxes = getattr(result, "boxes", None)
        scores = getattr(result, "scores", None)
        if boxes is None or len(boxes) == 0:
            return []
        candidates = []
        h, w = image_rgb.shape[:2]
        for idx, raw in enumerate(boxes):
            poly = np.asarray(raw, dtype=np.float32).reshape(4, 2)
            if not np.isfinite(poly).all():
                continue
            xs = poly[:, 0]; ys = poly[:, 1]
            bw = float(xs.max() - xs.min()); bh = float(ys.max() - ys.min())
            if bh < 7 or bw < 12 or (bh > 0.45 * h and bw > 0.45 * w):
                continue
            conf = float(scores[idx]) if scores is not None and idx < len(scores) else 1.0
            if conf < minimum_confidence:
                continue
            # Ignore polygons entirely off-screen.
            if xs.max() < 0 or xs.min() >= w or ys.max() < 0 or ys.min() >= h:
                continue
            candidates.append(poly)
        return candidates

    @staticmethod
    def _mask_for_poly(rgb, points, mode, expand_px, padding_px):
        h, w = rgb.shape[:2]
        minxy = np.floor(points.min(axis=0) - padding_px - expand_px - 3).astype(int)
        maxxy = np.ceil(points.max(axis=0) + padding_px + expand_px + 4).astype(int)
        x0, y0 = np.maximum(minxy, [0, 0])
        x1, y1 = np.minimum(maxxy, [w, h])
        if x1 <= x0 or y1 <= y0:
            return None
        roi = rgb[y0:y1, x0:x1]
        rh, rw = roi.shape[:2]
        poly = np.round(points - np.array([[x0, y0]])).astype(np.int32)
        roi_poly = np.zeros((rh, rw), dtype=np.uint8)
        cv2.fillConvexPoly(roi_poly, poly, 255)
        if padding_px:
            k = 2 * padding_px + 1
            roi_poly = cv2.dilate(roi_poly, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        area = max(1, np.count_nonzero(roi_poly))
        if mode == "full_text_regions":
            # Reliable literal restoration but will also copy background/old person.
            out = cv2.GaussianBlur(roi_poly, (3, 3), 0.6).astype(np.float32) / 255
            return x0, y0, x1, y1, out

        gray = cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
        hsv = cv2.cvtColor(roi, cv2.COLOR_RGB2HSV)
        valid = roi_poly > 0
        vals = gray[valid]
        if vals.size < 10:
            return None
        median = float(np.median(vals))
        local = cv2.GaussianBlur(gray, (0, 0), sigmaX=max(2.0, min(12., rh / 5.)))
        # White/black/yellow/other saturated text are common in Reels.
        light = ((gray >= 197) & (roi.max(axis=2) - roi.min(axis=2) < 85) &
                 ((gray.astype(np.float32) - local >= 4) | (gray >= 232)))
        dark = ((gray <= 72) & (roi.max(axis=2) - roi.min(axis=2) < 80) &
                ((local - gray.astype(np.float32) >= 5) | (gray <= 28)))
        R, G, B = [roi[:, :, i].astype(np.int16) for i in range(3)]
        yellow = (R >= 142) & (G >= 100) & (B < (R * 0.77)) & (B < (G * 0.80))
        saturation = hsv[:, :, 1]
        color = (saturation >= 100) & (hsv[:, :, 2] >= 108)
        # Limit 'other color' to the strongest hue bin within the OCR polygon;
        # this avoids copying all the various colors of the original actor.
        hue_pixels = hsv[:, :, 0][color & valid]
        if len(hue_pixels) >= 7:
            hist = np.bincount((hue_pixels // 10).astype(np.int32), minlength=18)
            dominant = int(hist.argmax())
            dist = np.abs(hsv[:, :, 0].astype(np.int16) - (dominant * 10 + 5))
            color &= (np.minimum(dist, 180 - dist) <= 14)
        else:
            color[:] = False

        candidates = {
            "light_text": light,
            "dark_text": dark,
            "yellow_text": yellow,
            "colored_text": color,
        }
        if mode == "light_text":
            order = ["light_text"]
        elif mode == "dark_text":
            order = ["dark_text"]
        elif mode == "colored_text":
            order = ["yellow_text", "colored_text"]
        else:
            # Prefer legible, high contrast text when more than one mask is plausible.
            order = ["light_text", "yellow_text", "dark_text", "colored_text"]

        ranked = []
        for typ in order:
            raw = (candidates[typ] & valid).astype(np.uint8)
            coverage = float(np.count_nonzero(raw)) / area
            # OCR boxes are close to glyph outlines: writing typically covers 5-55%.
            if coverage < 0.015 or coverage > 0.58:
                continue
            labels, cmap, stats, _ = cv2.connectedComponentsWithStats(raw, 8)
            filtered = np.zeros_like(raw)
            comps = 0
            for k in range(1, labels):
                cx, cy, cw, ch, count = map(int, stats[k])
                if count < max(2, area // 8000):
                    continue
                # A massive bright region is probably clothing, not a glyph.
                if count > 0.34 * area and ch > 0.67 * rh:
                    continue
                filtered[cmap == k] = 1
                comps += 1
            if not comps:
                continue
            cov = float(np.count_nonzero(filtered)) / area
            if cov < 0.012:
                continue
            # High contrast / moderate coverage / multiple shapes favour text.
            score = 1.2 - abs(cov - 0.20) * 1.5 + min(comps, 15) * 0.012
            if typ == "light_text": score += 0.16
            if typ == "yellow_text": score += 0.09
            if typ == "dark_text": score += 0.035
            ranked.append((score, filtered))
        if not ranked:
            return None
        _, glyph = max(ranked, key=lambda x:x[0])
        if expand_px > 0:
            k = 2 * expand_px + 1
            glyph = cv2.dilate(glyph, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        glyph = glyph.astype(np.float32) * valid.astype(np.float32)
        # Subpixel anti-aliased glyph boundaries, while centres remain opaque.
        glyph = cv2.GaussianBlur(glyph, (3, 3), 0.5)
        glyph *= valid.astype(np.float32)
        return x0, y0, x1, y1, np.clip(glyph, 0.0, 1.0)

    def restore(self, original_images, processed_images, enabled, text_mode,
                scan_every_n_frames, detection_confidence, glyph_expand_px,
                text_box_padding_px, blend_strength):
        count = len(processed_images)
        if count == 0:
            raise ValueError("[H3 Text Recovery] Empty processed_images batch")
        height, width = processed_images.shape[1:3]
        # Don't initialize OCR if the node was intentionally bypassed.
        if not enabled or blend_strength <= 0:
            zero_mask = torch.zeros((count, height, width), dtype=torch.float32, device=processed_images.device)
            return processed_images, zero_mask, "OCR restoration disabled"
        if abs(len(original_images) - count) > 1:
            raise ValueError(
                f"[H3 Text Recovery] Original/generated frame counts differ: "
                f"{len(original_images)} vs {count}. Check the 24fps input and H3 output."
            )
        ocr = self._engine()
        stride = max(1, int(scan_every_n_frames))
        keyframes = list(range(0, count, stride))
        if keyframes[-1] != count - 1:
            keyframes.append(count - 1)
        cached_boxes = {}
        for k in keyframes:
            orig = self._rgb8(original_images[min(k, len(original_images)-1)])
            if orig.shape[:2] != (height, width):
                orig = cv2.resize(orig, (width, height), interpolation=cv2.INTER_LANCZOS4)
            cached_boxes[k] = self._detect(orig, ocr, detection_confidence)
        # On frames between OCR scans, use nearest keyframe's polygons.
        # OCR is re-run often enough (default 8 scans/s at 24fps) to handle subtitles.
        saved = torch.empty_like(processed_images)
        all_masks = torch.empty((count, height, width), dtype=torch.float32, device=processed_images.device)
        frame_with_text = 0
        touched_pixels = 0
        import bisect
        for i in range(count):
            source = self._rgb8(original_images[min(i, len(original_images)-1)])
            if source.shape[:2] != (height, width):
                source = cv2.resize(source, (width, height), interpolation=cv2.INTER_LANCZOS4)
            edited = processed_images[i].detach().float().cpu().numpy()
            idx = bisect.bisect_left(keyframes, i)
            if idx == len(keyframes):
                closest = keyframes[-1]
            elif idx == 0:
                closest = keyframes[0]
            else:
                lo, hi = keyframes[idx - 1], keyframes[idx]
                closest = lo if i - lo <= hi - i else hi
            polys = cached_boxes[closest]
            alpha = np.zeros((height, width), dtype=np.float32)
            for poly in polys:
                result = self._mask_for_poly(source, poly, text_mode,
                                             glyph_expand_px, text_box_padding_px)
                if result is None:
                    continue
                x0, y0, x1, y1, m = result
                target = alpha[y0:y1, x0:x1]
                np.maximum(target, m, out=target)
            if np.count_nonzero(alpha > 0.08):
                frame_with_text += 1
                touched_pixels += int(np.count_nonzero(alpha > 0.08))
                weight = (alpha * blend_strength)[:, :, None]
                merged = edited * (1. - weight) + (source.astype(np.float32) / 255.) * weight
                saved[i] = torch.from_numpy(np.ascontiguousarray(merged)).to(
                    device=processed_images.device, dtype=processed_images.dtype)
            else:
                saved[i] = processed_images[i]
            all_masks[i] = torch.from_numpy(alpha).to(device=processed_images.device)
        line_count = sum(map(len, cached_boxes.values()))
        report = (f"Restored original caption pixels | {count} frames, "
                  f"OCR scanned {len(keyframes)} frames, {line_count} text regions, "
                  f"protected {frame_with_text} frames, {touched_pixels:,} pixels; "
                  f"mode={text_mode}")
        _LOG.info(report)
        return saved, all_masks, report


NODE_CLASS_MAPPINGS = {"H3RestoreOverlayText": H3RestoreOverlayText}
NODE_DISPLAY_NAME_MAPPINGS = {"H3RestoreOverlayText": "H3 • Restore Source Overlay Text (OCR)"}
