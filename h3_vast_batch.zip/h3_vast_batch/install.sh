#!/usr/bin/env bash
# Run on Vast AFTER extracting this directory to /workspace/h3_vast_batch.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PYTHON="${H3_PYTHON:-python3}"

if [[ "${VIRTUAL_ENV:-}" != '' ]]; then
  $PYTHON -m pip install -r "$ROOT/requirements.txt"
else
  "$PYTHON" -m venv "$ROOT/.venv"
  "$ROOT/.venv/bin/python" -m pip install --upgrade pip
  "$ROOT/.venv/bin/python" -m pip install -r "$ROOT/requirements.txt"
  PYTHON="$ROOT/.venv/bin/python"
fi

# Caller should set H3_COMFY_DIRS explicitly if each GPU has a separate copy.
if [[ -n "${H3_COMFY_DIRS:-}" ]]; then
  IFS=',' read -ra COMFY_DIRS <<< "$H3_COMFY_DIRS"
else
  COMFY_DIRS=()
  for dir in /workspace/ComfyUI /workspace/ComfyUI-* /workspace/comfyui-gpu* /opt/ComfyUI; do
    [[ -d "$dir/custom_nodes" ]] && COMFY_DIRS+=("$dir")
  done
fi

for path in "${COMFY_DIRS[@]}"; do
  path="${path%/}"
  if [[ -d "$path/custom_nodes" ]]; then
    if [[ -e "$path/custom_nodes/h3_batch_nodes" && ! -L "$path/custom_nodes/h3_batch_nodes" ]]; then
      echo "WARNING: $path/custom_nodes/h3_batch_nodes already exists (not overwriting)"
    else
      ln -sfn "$ROOT/custom_nodes/h3_batch_nodes" "$path/custom_nodes/h3_batch_nodes"
      echo "Installed custom node: $path/custom_nodes/h3_batch_nodes"
    fi
  fi
done

if [[ "${#COMFY_DIRS[@]}" == 0 ]]; then
  echo 'WARNING: no ComfyUI installation detected. Set H3_COMFY_DIRS=/path/to/ComfyUI,another/path then rerun.'
fi

if [[ "$(id -u)" == 0 && -d /etc/supervisor/conf.d && -x "$(command -v supervisorctl || true)" ]]; then
  if [[ -x "$ROOT/.venv/bin/gunicorn" ]]; then
    CMD="$ROOT/.venv/bin/gunicorn"
  else
    CMD="$(command -v gunicorn)"
  fi
  cat > /etc/supervisor/conf.d/h3-batch-panel.conf <<EOF
[program:h3-batch-panel]
directory=$ROOT
command=$CMD --workers 1 --threads 16 --bind 127.0.0.1:18766 --timeout 120 server:app
autostart=true
autorestart=true
startsecs=5
stdout_logfile=/dev/stdout
stdout_logfile_maxbytes=0
redirect_stderr=true
EOF
  supervisorctl reread
  supervisorctl update
  echo 'Supervisor service: h3-batch-panel'
else
  echo 'Supervisor unavailable. Start manually with:'
  echo "cd '$ROOT' && $PYTHON server.py"
fi
cat <<'EOF'

NEXT:
1) Restart all four ComfyUI processes ONCE (new custom nodes require restart).
2) Verify http://127.0.0.1:18766 from Vast (curl -I works).
3) Add this to existing PORTAL_CONFIG (preserve ALL current entries):
     |localhost:8766:18766:/:H3 Batch API
4) Configure Vast template to expose port 8766 (or choose an ALREADY-exposed port).
5) If /etc/portal.yaml already exists, edit its services there and restart Caddy.
6) If your ComfyUI servers listen on other ports, configure H3_COMFY_PORTS.
EOF
