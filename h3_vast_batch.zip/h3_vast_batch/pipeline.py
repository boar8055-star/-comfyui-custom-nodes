"""Split the user's actual H3 ComfyUI API graph into three executable passes.

We prune graph dependencies from the stage-specific save node. No samplers or
model settings are rewritten; only fixed inputs, inter-pass edges and outputs.
"""
import copy
import json
from pathlib import Path

WORKFLOW = Path(__file__).with_name('workflow_api.json')
OUT = '99099'
STAGE3_LOADER = '99001'


def prune(nodes, roots):
    wanted = set()
    def visit(key):
        if key in wanted:
            return
        if key not in nodes:
            raise ValueError('Missing graph node: ' + key)
        wanted.add(key)
        for val in nodes[key].get('inputs', {}).values():
            if isinstance(val, list) and len(val) == 2 and isinstance(val[0], str) and val[0] in nodes:
                visit(val[0])
    for root in roots:
        visit(root)
    return {k: v for k, v in nodes.items() if k in wanted}


def saver(images, audio, dest, fps, intermediate_lossless):
    return {
        'class_type': 'H3BatchSaveVideo',
        'inputs': {
            'frames': [images, 0],
            'audio': [audio, 0],
            'output_path': str(dest),
            'fps': fps,
            'lossless': bool(intermediate_lossless),
            'crf': 14 if fps == 30 else 10,
            'final_mp4': fps == 30,
        },
        '_meta': {'title': 'H3 Batch | write stage artifact'},
    }


def make_graph(stage, original_video, body, stage1_path, stage2_path, final_path, face_front=None, face_side=None, lossless=False):
    nodes = copy.deepcopy(json.loads(WORKFLOW.read_text(encoding='utf-8')))
    if stage == 1:
        # H3FolderCycle is stateful and non-deterministic with four processes;
        # instead give every execution its exact video and body reference.
        nodes['11307'] = {
            'class_type': 'H3BatchInputs',
            'inputs': {'body_path': str(body), 'video_path': str(original_video)},
            '_meta': {'title': 'H3 Batch | fixed source video + body'},
        }
        nodes[OUT] = saver('12045', '12863', stage1_path, 24, lossless)
    elif stage == 2:
        # Stage 1 output becomes Stage 2's guide, video info and audio source.
        # Bypasses 12045 without reevaluating Stage 1 weights/sampler.
        nodes['11191']['inputs']['video'] = str(stage1_path)
        nodes['1258']['inputs']['image'] = ['11191', 0]
        face_front = face_front or body
        face_side = face_side or body
        for key, path in [('1242', face_front), ('1243', face_side), ('1269', face_side)]:
            nodes[key] = {'class_type': 'H3BatchLoadImage',
                          'inputs': {'path': str(path)},
                          '_meta': {'title': 'H3 Batch | face reference ' + key}}
        nodes[OUT] = saver('1273', '1218', stage2_path, 24, lossless)
    elif stage == 3:
        # Use the full uncropped Stage 2 output, and its generated audio.
        nodes[STAGE3_LOADER] = {
            'class_type': 'VHS_LoadVideoPath',
            'inputs': {'video': str(stage2_path), 'force_rate': 24,
                       'custom_width': 0, 'custom_height': 0,
                       'frame_load_cap': 243, 'skip_first_frames': 0,
                       'select_every_nth': 1, 'format': 'None'},
            '_meta': {'title': 'H3 Batch | load Stage 2 video'},
        }
        nodes['11313']['inputs']['frames'] = [STAGE3_LOADER, 0]
        nodes['11315']['inputs']['image'] = [STAGE3_LOADER, 0]
        nodes[OUT] = saver('11317', STAGE3_LOADER, final_path, 30, False)
        nodes[OUT]['inputs']['audio'] = [STAGE3_LOADER, 2]
        nodes[OUT]['inputs']['crf'] = 14
    else:
        raise ValueError('Unknown stage: ' + str(stage))
    return prune(nodes, [OUT])


def summary():
    dummy = dict(original_video='/workspace/source/test.mp4',
                 body='/workspace/body/ref.png',
                 stage1_path='/workspace/batch/stage1/test.mkv',
                 stage2_path='/workspace/batch/stage2/test.mkv',
                 final_path='/workspace/batch/final/test.mp4')
    return {f'stage_{i}': len(make_graph(i, **dummy)) for i in (1, 2, 3)}


if __name__ == '__main__':
    print(json.dumps(summary(), indent=2))
