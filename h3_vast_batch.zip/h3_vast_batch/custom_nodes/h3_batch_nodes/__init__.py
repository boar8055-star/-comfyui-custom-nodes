"""Small, deterministic ComfyUI nodes used by H3 Batch panel.

This node pack must be installed in EACH independent ComfyUI worker tree.
Never expose its unrestricted path inputs to untrusted ComfyUI clients.
"""
import os
import subprocess
import tempfile
import wave
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps


class H3BatchLoadImage:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'path': ('STRING', {'default': ''})}}

    RETURN_TYPES = ('IMAGE',)
    FUNCTION = 'load'
    CATEGORY = 'H3 Batch'

    def load(self, path):
        p = Path(path)
        if not p.is_file():
            raise FileNotFoundError(path)
        with Image.open(p) as image:
            image = ImageOps.exif_transpose(image).convert('RGB')
            pixels = np.asarray(image, dtype=np.float32) / 255.0
        return (torch.from_numpy(pixels)[None, ...],)

    @classmethod
    def IS_CHANGED(cls, path):
        p = Path(path)
        return str((p.stat().st_mtime_ns, p.stat().st_size)) if p.exists() else path


class H3BatchInputs:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'body_path': ('STRING', {'default': ''}),
            'video_path': ('STRING', {'default': ''}),
        }}

    RETURN_TYPES = ('IMAGE', 'STRING', 'STRING')
    RETURN_NAMES = ('body_image', 'video_path', 'selected_files')
    FUNCTION = 'load'
    CATEGORY = 'H3 Batch'

    def load(self, body_path, video_path):
        if not Path(video_path).is_file():
            raise FileNotFoundError(video_path)
        image, = H3BatchLoadImage().load(body_path)
        return image, str(Path(video_path).resolve()), f'{Path(video_path).name} | {Path(body_path).name}'

    @classmethod
    def IS_CHANGED(cls, body_path, video_path):
        return H3BatchLoadImage.IS_CHANGED(body_path) + '/' + H3BatchLoadImage.IS_CHANGED(video_path)


class H3BatchSaveVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'frames': ('IMAGE',),
            'audio': ('AUDIO',),
            'output_path': ('STRING', {'default': '/workspace/h3_batch/out.mp4'}),
            'fps': ('INT', {'default': 24, 'min': 1, 'max': 240}),
            'lossless': ('BOOLEAN', {'default': False}),
            'crf': ('INT', {'default': 10, 'min': 0, 'max': 51}),
            'final_mp4': ('BOOLEAN', {'default': False}),
        }}

    RETURN_TYPES = ('STRING',)
    RETURN_NAMES = ('saved_path',)
    FUNCTION = 'save'
    OUTPUT_NODE = True
    CATEGORY = 'H3 Batch'

    def save(self, frames, audio, output_path, fps, lossless, crf, final_mp4):
        path = Path(output_path).resolve()
        if final_mp4 and path.suffix.lower() != '.mp4':
            raise ValueError('Final videos must be MP4')
        if not final_mp4 and path.suffix.lower() != '.mkv':
            raise ValueError('Intermediate videos must be MKV')
        if not path.parent.is_dir():
            path.parent.mkdir(parents=True, exist_ok=True)
        if len(frames.shape) != 4 or frames.shape[3] < 3:
            raise ValueError('Expected frames as [count, height, width, channels]')
        count, height, width, channels = frames.shape
        if count == 0:
            raise ValueError('Cannot save zero frames')
        temp_audio = None
        temp_video = None
        try:
            with tempfile.NamedTemporaryFile(prefix='.h3batch-', suffix=path.suffix,
                                             dir=path.parent, delete=False) as f:
                temp_video = f.name
            wave_data = None
            if audio and isinstance(audio, dict) and 'waveform' in audio:
                waveform = audio['waveform']
                if isinstance(waveform, torch.Tensor):
                    waveform = waveform.detach().cpu().float().numpy()
                waveform = np.asarray(waveform)
                if waveform.ndim == 3:
                    waveform = waveform[0]
                if waveform.ndim == 1:
                    waveform = waveform[None, :]
                if waveform.ndim == 2 and waveform.shape[1] > 0:
                    wave_data = np.clip(waveform.T, -1, 1)
                    sample_rate = int(audio.get('sample_rate', 44100))
                    with tempfile.NamedTemporaryFile(prefix='.h3batch-', suffix='.wav',
                                                     dir=path.parent, delete=False) as f:
                        temp_audio = f.name
                    with wave.open(temp_audio, 'wb') as wav:
                        wav.setnchannels(int(wave_data.shape[1]))
                        wav.setsampwidth(2)
                        wav.setframerate(sample_rate)
                        wav.writeframes((wave_data * 32767).astype(np.int16).tobytes())
            command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                       '-f', 'rawvideo', '-pixel_format', 'rgb24', '-video_size',
                       f'{width}x{height}', '-framerate', str(fps), '-i', 'pipe:0']
            if temp_audio:
                command += ['-i', temp_audio]
            if final_mp4:
                command += ['-map', '0:v:0', '-c:v', 'libx264', '-preset', 'veryfast',
                            '-crf', str(crf), '-pix_fmt', 'yuv420p', '-movflags', '+faststart']
            elif lossless:
                command += ['-map', '0:v:0', '-c:v', 'ffv1', '-level', '3', '-pix_fmt', 'gbrp']
            else:
                command += ['-map', '0:v:0', '-c:v', 'libx264', '-preset', 'veryfast',
                            '-crf', str(crf), '-pix_fmt', 'yuv444p']
            if temp_audio:
                command += ['-map', '1:a:0', '-c:a', 'aac' if final_mp4 else 'flac']
                if final_mp4:
                    command += ['-b:a', '192k']
            else:
                command += ['-an']
            command += [temp_video]
            process = subprocess.Popen(command, stdin=subprocess.PIPE,
                                       stderr=subprocess.PIPE)
            try:
                for i in range(count):
                    frame = frames[i, :, :, :3].detach().cpu().clamp(0, 1)
                    data = (frame.numpy() * 255.0).round().astype(np.uint8)
                    process.stdin.write(data.tobytes())
                process.stdin.close()
                result = process.stderr.read()
                code = process.wait(timeout=900)
                if code:
                    raise RuntimeError(f'FFmpeg exit {code}: {result.decode(errors="replace")[-3000:]}')
            except Exception:
                process.kill()
                process.wait()
                raise
            if not Path(temp_video).is_file() or Path(temp_video).stat().st_size == 0:
                raise RuntimeError('FFmpeg produced no video')
            os.replace(temp_video, path)
            temp_video = None
            return {'ui': {'text': [str(path)]}, 'result': (str(path),)}
        finally:
            for name in (temp_audio, temp_video):
                if name:
                    try:
                        Path(name).unlink(missing_ok=True)
                    except OSError:
                        pass


NODE_CLASS_MAPPINGS = {
    'H3BatchInputs': H3BatchInputs,
    'H3BatchLoadImage': H3BatchLoadImage,
    'H3BatchSaveVideo': H3BatchSaveVideo,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    'H3BatchInputs': 'H3 Batch Inputs',
    'H3BatchLoadImage': 'H3 Batch Load Image',
    'H3BatchSaveVideo': 'H3 Batch Save Video',
}
