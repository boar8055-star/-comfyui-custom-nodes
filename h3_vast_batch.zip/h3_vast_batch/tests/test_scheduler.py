import importlib
import os
import sys
import tempfile
import threading
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch

# The CI sandbox has no Flask distribution. Stub only routing/wrappers so that
# the stage scheduler can still be exercised without network/GPU access.
module = types.ModuleType('flask')
class Flask:
    def __init__(self, name):
        self.name = name
    def get(self, *args, **kwargs):
        return lambda f: f
    post = get
    before_request = get
module.Flask = Flask
module.Response = type('Response', (), {})
module.jsonify = lambda x: x
module.render_template = lambda x: x
module.request = None
sys.modules.setdefault('flask', module)
TMP = tempfile.TemporaryDirectory()
os.environ['H3_BATCH_HOME'] = TMP.name
os.environ['H3_ALLOWED_ROOTS'] = TMP.name
import server

class SchedulerTests(unittest.TestCase):
    def test_stage_barrier_parallel_workers(self):
        log=[]
        lock=threading.Lock()
        run_id='batchtest'
        base=Path(TMP.name)
        tasks=[]
        for i in range(12):
            item={'video':str(base/f'v{i}.mp4'), 'body':str(base/'b.png'),
                  'face_front':str(base/'b.png'), 'face_side':str(base/'b.png'),
                  'stage1':str(base/f's1_{i}.mkv'), 'stage2':str(base/f's2_{i}.mkv'),
                  'final':str(base/f'f_{i}.mp4'),
                  'stages':{str(j):{'status':'pending','gpu':None,'updated':None,'error':''} for j in (1,2,3)}}
            tasks.append(item)
        server.ACTIVE={'id':run_id,'status':'starting','selected_gpus':[0,1,2,3],
                       'gpus':[], 'lossless':False, 'tasks':tasks}
        server.ABORT.clear()
        def fake_run(session,port,stage,item,lossless,stop):
            with lock:
                log.append(('start',stage,port,time.monotonic()))
            time.sleep(.02 + 0.005 * int(port[-1]))
            Path(item[{1:'stage1',2:'stage2',3:'final'}[stage]]).write_bytes(b'abc')
            with lock:
                log.append(('end',stage,port,time.monotonic()))
            return 'new'
        with patch.object(server,'check_worker',side_effect=lambda _: {'online':True}), \
             patch.object(server,'run_one',side_effect=fake_run), \
             patch.object(server.requests, 'post'):
            server.work(run_id)
        self.assertEqual(server.ACTIVE['status'], 'finished')
        self.assertEqual({e[2] for e in log}, set(server.COMFY[:4]))
        for i in (1,2):
            self.assertLess(max(x[3] for x in log if x[:2]==('end',i)),
                            min(x[3] for x in log if x[:2]==('start',i+1)))
        for t in server.ACTIVE['tasks']:
            self.assertTrue(all(v['status']=='done' for v in t['stages'].values()))

if __name__=='__main__':
    unittest.main()
