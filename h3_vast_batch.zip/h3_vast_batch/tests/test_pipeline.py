import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from pipeline import make_graph

ARG = dict(original_video='/workspace/vid.mp4', body='/workspace/body.png',
           stage1_path='/workspace/a.mkv',stage2_path='/workspace/b.mkv',
           final_path='/workspace/c.mp4')


class WorkflowTests(unittest.TestCase):
    def test_pruning_separates_model_passes(self):
        a, b, c = (make_graph(i, **ARG) for i in (1, 2, 3))
        self.assertIn('12014', a)
        self.assertNotIn('1198', a)
        self.assertIn('1198', b)
        self.assertNotIn('12014', b)
        self.assertNotIn('12045', b)
        self.assertIn('11313', c)
        self.assertNotIn('1198', c)
        self.assertNotIn('12014', c)
        self.assertIn('11314', c)
        self.assertIn('11315', c)
        self.assertIn('11317', c)
        self.assertNotIn('11307', b)
        self.assertEqual(b['11191']['inputs']['video'], ARG['stage1_path'])
        self.assertEqual(b['1258']['inputs']['image'], ['11191',0])
        self.assertEqual(c['99099']['inputs']['audio'], ['99001',2])
        self.assertEqual(c['11315']['inputs']['image'], ['99001',0])

    def test_every_link_exists(self):
        for i in (1, 2, 3):
            g = make_graph(i, **ARG)
            for node in g.values():
                for v in node.get('inputs',{}).values():
                    if isinstance(v,list) and len(v)==2:
                        self.assertIn(v[0], g)

    def test_stage1_fixed_source(self):
        a = make_graph(1, **ARG)
        self.assertEqual(a['11307']['class_type'],'H3BatchInputs')
        self.assertEqual(a['11307']['inputs']['video_path'], ARG['original_video'])
        self.assertEqual(a['11307']['inputs']['body_path'], ARG['body'])

    def test_dynamic_face_ref(self):
        b = make_graph(2, **ARG, face_front='/workspace/ff.png',face_side='/workspace/fs.png')
        self.assertEqual(b['1242']['inputs']['path'],'/workspace/ff.png')
        self.assertEqual(b['1243']['inputs']['path'],'/workspace/fs.png')
        self.assertNotIn('1269', b)  # original dead node, safely pruned


if __name__ == '__main__':
    unittest.main()
